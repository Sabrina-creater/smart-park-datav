import{r as e}from"./rolldown-runtime-Dw2cE7zH.js";import{A as t,C as n,D as r,E as i,O as a,S as o,T as s,_ as c,a as l,b as u,c as d,d as f,f as p,g as m,h,i as g,l as _,m as v,n as ee,o as te,p as y,r as b,s as ne,t as re,u as ie,v as x,w as ae,x as oe,y as se}from"./three-CUqPPu0l.js";import{n as S,r as C,t as w}from"./index-BWDIBO7Q.js";import{a as ce,c as le,d as ue,f as de,i as T,l as fe,m as pe,n as me,o as he,p as ge,r as _e,s as ve,t as ye,u as be}from"./echarts-UBO_R8mO.js";var E=e(t(),1),xe=e=>e;function Se(e,t=xe){let n=E.useSyncExternalStore(e.subscribe,E.useCallback(()=>t(e.getState()),[e,t]),E.useCallback(()=>t(e.getInitialState()),[e,t]));return E.useDebugValue(n),n}var Ce=e=>{let t=r(e),n=e=>Se(t,e);return Object.assign(n,t),n},we=(e=>e?Ce(e):Ce),Te=e=>(t,n,r)=>{let i=r.subscribe;return r.subscribe=((e,t,n)=>{let a=e;if(t){let i=n?.equalityFn||Object.is,o=e(r.getState());a=n=>{let r=e(n);if(!i(o,r)){let e=o;t(o=r,e)}},n?.fireImmediately&&t(o,o)}return i(a)}),e(t,n,r)},Ee={landmark:`城市地标`,skyscraper:`超高层`,historic:`历史建筑`,hotel:`酒店`,office:`商务楼`,culture:`文化场馆`},De={landmark:[`#1a0424`,`#e01fb8`,`#ff7ae6`,`#ffc4f4`],skyscraper:[`#04112a`,`#0d77ff`,`#54c6ff`,`#bce7ff`],historic:[`#ffc45e`,`#5a3a0e`,`#ffe9a8`,`#ffe0a0`],hotel:[`#f0b24a`,`#4a3014`,`#ffe3b0`,`#ffe0a0`],office:[`#04101f`,`#0a6a9c`,`#46deff`,`#b1f0ff`],culture:[`#0b2d3a`,`#35d6a0`,`#a8ffe0`,`#d0ffee`]},Oe=[`historic`,`hotel`],D=[{id:`P1`,beacon:!0,label:!0,name:`东方明珠`,type:`landmark`,shape:`pearl`,position:[-15.5,-10],size:[5,33,5],height:468,floors:3,builtYear:1994,people:6800,energyToday:9800,load:.76},{id:`P2`,beacon:!0,label:!0,name:`上海中心大厦`,type:`skyscraper`,shape:`twist`,position:[8.5,-15.5],size:[6,45,6],height:632,floors:128,builtYear:2015,people:12400,energyToday:38600,load:.71},{id:`P3`,beacon:!0,label:!0,name:`环球金融中心`,type:`skyscraper`,shape:`swfc`,position:[2.5,-19.5],size:[5,35,4],height:492,floors:101,builtYear:2008,people:9600,energyToday:29400,load:.68},{id:`P4`,palette:[`#2a1806`,`#ffb340`,`#ffe4a0`,`#fff2d0`],beacon:!0,name:`金茂大厦`,type:`skyscraper`,shape:`jinmao`,position:[-6.5,-14.5],size:[5,30,5],height:420,floors:88,builtYear:1999,people:8200,energyToday:24800,load:.73},{id:`P5`,name:`上海国际会议中心`,type:`culture`,shape:`globe`,position:[-24,-10],size:[8,4,5],height:70,floors:10,builtYear:1999,people:1900,energyToday:6200,load:.52},{id:`P6`,beacon:!0,screen:!0,name:`震旦国际大楼`,type:`office`,position:[-9,-9],size:[4,13,4],height:185,floors:38,builtYear:2003,people:3e3,energyToday:8200,load:.82},{id:`P7`,beacon:!0,name:`中银大厦`,type:`office`,position:[15,-14],size:[4,18,4],height:226,floors:53,builtYear:2e3,people:3600,energyToday:9800,load:.79},{id:`P8`,beacon:!0,name:`平安金融大厦`,type:`office`,position:[-13,-20],size:[4,17,4],height:233,floors:48,builtYear:2009,people:3300,energyToday:9100,load:.74},{id:`P9`,screen:!0,name:`花旗集团大厦`,type:`office`,position:[-19,-16],size:[4,14,4],height:180,floors:42,builtYear:2005,people:2800,energyToday:7600,load:.69},{id:`P10`,beacon:!0,name:`上海国金中心`,type:`office`,position:[17,-20],size:[4,19,4],height:260,floors:58,builtYear:2010,people:4300,energyToday:12400,load:.8},{id:`P11`,name:`浦东美术馆`,type:`culture`,position:[-35,-8.8],size:[6,3.5,4],height:30,floors:4,builtYear:2021,people:1400,energyToday:2600,load:.47},{id:`P12`,beacon:!0,name:`浦东香格里拉大酒店`,type:`hotel`,position:[5,-9.5],size:[5,12,4],height:152,floors:36,builtYear:1998,people:1700,energyToday:8400,load:.86},{id:`B1`,name:`亚细亚大楼`,type:`historic`,position:[35.8,15.5],size:[5,5.2,4],height:36,floors:8,builtYear:1916,people:320,energyToday:1100,load:.58},{id:`B2`,name:`上海总会大楼`,type:`historic`,position:[30.55,15.5],size:[4.5,4.6,4],height:30,floors:6,builtYear:1910,people:260,energyToday:960,load:.62},{id:`B5`,name:`汇丰银行大楼`,type:`historic`,shape:`dome`,position:[23.55,15.5],size:[8.5,5.4,4.5],height:40,floors:7,builtYear:1923,people:860,energyToday:2400,load:.66},{id:`B6`,label:!0,name:`海关大楼`,type:`historic`,shape:`clock`,position:[16.05,15.5],size:[5.5,9.6,4.5],height:79,floors:11,builtYear:1927,people:540,energyToday:1800,load:.6},{id:`B7`,name:`交通银行大楼`,type:`historic`,position:[7.8,15.5],size:[4,4.6,4],height:31,floors:6,builtYear:1948,people:300,energyToday:1040,load:.57},{id:`B8`,name:`字林西报大楼`,type:`historic`,position:[3.4,15.5],size:[3.8,4.9,4],height:38,floors:9,builtYear:1924,people:330,energyToday:1120,load:.63},{id:`B9`,name:`外滩18号`,type:`historic`,position:[-.8,15.5],size:[3.6,4.6,4],height:30,floors:5,builtYear:1923,people:420,energyToday:1500,load:.78},{id:`B10`,name:`和平饭店南楼`,type:`hotel`,position:[-5,15.5],size:[3.8,4.4,4],height:28,floors:6,builtYear:1908,people:260,energyToday:1300,load:.81},{id:`B11`,label:!0,name:`和平饭店北楼`,type:`hotel`,shape:`pyramid`,position:[-12.4,15.5],size:[5,7.4,4.5],height:77,floors:13,builtYear:1929,people:680,energyToday:3200,load:.88,accent:`#3fd0a0`},{id:`B12`,name:`中国银行大楼`,type:`historic`,shape:`pyramid`,position:[-17.9,15.5],size:[5,6.2,4.5],height:70,floors:17,builtYear:1937,people:760,energyToday:2600,load:.64,accent:`#5aa0ff`},{id:`B13`,name:`怡和洋行大楼`,type:`historic`,position:[-23.15,15.5],size:[4.5,4.8,4],height:32,floors:7,builtYear:1922,people:290,energyToday:1e3,load:.56},{id:`B14`,name:`外滩源壹号`,type:`culture`,position:[-30,20.5],size:[3.6,2.6,4],height:15,floors:2,builtYear:1873,people:160,energyToday:420,load:.4},{id:`B15`,label:!0,name:`上海大厦`,type:`hotel`,position:[-38.5,15.5],size:[5,7.5,4.5],height:77,floors:22,builtYear:1934,people:520,energyToday:2900,load:.74}],O=Object.fromEntries(D.map(e=>[e.id,e])),ke=[{position:[30,-26.6],size:[6,9,2.6],type:`office`},{position:[22,-26.6],size:[5,12,2.6],type:`office`},{position:[12,-26.6],size:[6,8,2.6],type:`office`},{position:[5,-26.6],size:[4,14,2.6],type:`office`},{position:[-8,-26.6],size:[5,10,2.6],type:`office`},{position:[-18,-26.6],size:[6,7,2.6],type:`office`},{position:[-26,-26.6],size:[5,11,2.6],type:`office`},{position:[-36,-26.6],size:[6,6,2.6],type:`office`},{position:[-36,-17],size:[5,9,4],type:`office`},{position:[36,-14],size:[5,8,4],type:`office`},{position:[36,-22],size:[5,6,4],type:`office`},{position:[36,21.5],size:[6,3.2,4],type:`historic`},{position:[27,21.5],size:[6,2.8,4],type:`historic`},{position:[18,21.5],size:[6,3.6,4],type:`historic`},{position:[5,21.5],size:[6,3,4],type:`historic`},{position:[-3,21.5],size:[6,4,4],type:`historic`},{position:[-14,21.5],size:[6,3.2,4],type:`historic`},{position:[-22,21.5],size:[6,3.8,4],type:`historic`},{position:[-39,21.5],size:[5,4.2,4],type:`historic`}],Ae=[84,56],k=[{name:`黄浦江`,x:[-42,42],z:[-4,8]},{name:`苏州河`,x:[-35,-32],z:[8,28]}],je=[{from:[40,8.7],to:[-31,8.7],step:2.2},{from:[40,13.4],to:[-31,13.4],step:3},{from:[-36,13.4],to:[-40,13.4],step:4},{from:[40,-7.4],to:[-40,-7.4],step:5},{from:[40,-4.7],to:[-40,-4.7],step:6}],Me=[[22,9.3],[-2,9.3],[-24,9.3]],Ne={x:-33.5,z:11.5,span:5,width:3.6},Pe=[{name:`中山东一路`,from:[42,11.5],to:[-42,11.5],width:3},{name:`滨江大道`,from:[42,-5.5],to:[-42,-5.5],width:2.4},{name:`世纪大道`,from:[-2,-5.5],to:[-2,-28],width:2.4},{name:`陆家嘴环路·东`,from:[-30,-5.5],to:[-30,-24],width:2.4},{name:`陆家嘴环路·西`,from:[30,-5.5],to:[30,-24],width:2.4},{name:`陆家嘴环路·南`,from:[30,-24],to:[-30,-24],width:2.4},{name:`汉口路`,from:[11.3,13],to:[11.3,28],width:2},{name:`南京东路`,from:[-8.4,13],to:[-8.4,28],width:2},{name:`北京东路`,from:[-27,13],to:[-27,28],width:2}],Fe=[{points:[[41,10.8],[-41,10.8],[-41,12.2],[41,12.2]],color:`#ffd166`,count:7,speed:.03},{points:[[41,-4.9],[-41,-4.9],[-41,-6.1],[41,-6.1]],color:`#7ff0ff`,count:4,speed:.035},{points:[[29.5,-6.3],[-29.5,-6.3],[-29.5,-23.4],[29.5,-23.4]],color:`#ff8fa3`,count:5,speed:.03}],Ie=[{points:[[46,.5],[-46,.5],[-46,2.5],[46,2.5]],count:4,speed:.012,kind:`cruise`},{points:[[46,5],[-46,5],[-46,6.5],[46,6.5]],count:3,speed:.018,kind:`ferry`}],A={visitorsToday:186420,peopleNow:D.reduce((e,t)=>e+t.people,0),energyToday:D.reduce((e,t)=>e+t.energyToday,0),devicesOnline:3860,capacity:.64,parkingUsed:1240,parkingTotal:1800,boatOccupancy:.72,merchants:630},j={hours:Array.from({length:24},(e,t)=>`${`${t}`.padStart(2,`0`)}:00`),today:[1200,600,300,200,300,900,2100,3800,5200,6800,7600,8400,8100,7900,8600,9200,9800,11200,13800,15200,14100,11800,7600,3600],yesterday:[1100,550,280,220,280,860,1900,3500,4900,6300,7100,7900,7700,7400,8100,8800,9300,10600,12900,14300,13500,11200,7100,3300]},M={slots:[`00`,`02`,`04`,`06`,`08`,`10`,`12`,`14`,`16`,`18`,`20`,`22`],in:[320,140,90,260,980,1120,960,1040,1180,1420,1360,820],out:[360,160,80,180,820,1060,1010,980,1240,1380,1480,960]},N={temperature:22.8,humidity:63,pm25:28,noise:58,co2:460,wind:3.6,aqi:39,aqiLevel:`优`,weather:`晴`,waterLevel:3.12},Le=[{name:`温度舒适度`,value:88,max:100},{name:`湿度舒适度`,value:72,max:100},{name:`空气质量`,value:94,max:100},{name:`噪音控制`,value:62,max:100},{name:`江面水质`,value:84,max:100},{name:`绿化覆盖`,value:70,max:100}],Re=[{name:`金融机构`,value:120},{name:`文旅观光`,value:86},{name:`餐饮`,value:164},{name:`零售`,value:212},{name:`酒店`,value:48}],P=[{id:1,time:`20:42`,buildingId:`B6`,type:`观景平台人流密度预警`,level:`高`,status:`待处理`},{id:2,time:`20:38`,buildingId:`P1`,type:`观光层客流超限`,level:`高`,status:`处理中`},{id:3,time:`20:31`,buildingId:`B11`,type:`外立面灯光故障`,level:`中`,status:`待处理`},{id:4,time:`20:20`,buildingId:`P5`,type:`码头游船靠泊异常`,level:`中`,status:`待处理`},{id:5,time:`20:05`,buildingId:`P2`,type:`电梯困人`,level:`高`,status:`已处理`},{id:6,time:`19:52`,buildingId:`B5`,type:`设备离线`,level:`中`,status:`处理中`},{id:7,time:`19:47`,buildingId:`B15`,type:`江堤水位预警`,level:`中`,status:`待处理`},{id:8,time:`19:30`,buildingId:`P3`,type:`消防烟感告警`,level:`高`,status:`已处理`},{id:9,time:`19:12`,buildingId:`B9`,type:`门禁异常`,level:`低`,status:`已处理`},{id:10,time:`18:58`,buildingId:`P4`,type:`能耗超限`,level:`低`,status:`已处理`},{id:11,time:`18:40`,buildingId:`B1`,type:`摄像头离线`,level:`低`,status:`处理中`},{id:12,time:`18:21`,buildingId:`P12`,type:`周界入侵`,level:`中`,status:`已处理`},{id:13,time:`17:55`,buildingId:`P11`,type:`展厅温湿度异常`,level:`低`,status:`已处理`},{id:14,time:`17:30`,buildingId:`B12`,type:`门禁异常`,level:`低`,status:`已处理`},{id:15,time:`17:02`,buildingId:`P6`,type:`LED 屏幕离线`,level:`低`,status:`已处理`}],ze={高:`#ff5f6d`,中:`#ffb400`,低:`#3fb6ff`},Be={待处理:`#ff5f6d`,处理中:`#ffb400`,已处理:`#35d6a0`},Ve=Array.from(new Set(P.filter(e=>e.status!==`已处理`).map(e=>e.buildingId))),F=we()(Te((e,t,n)=>({sceneReady:!1,flyLine:!0,beam:!0,labels:!0,vehicles:!0,boats:!0,autoRotate:!1,selected:null,hovered:null,toggle:t=>e(e=>({[t]:!e[t]})),select:n=>e({selected:t().selected===n?null:n}),focus:t=>e({selected:t}),hover:t=>e({hovered:t}),reset:()=>e(n.getInitialState())}))),I=we()(e=>({visitorsToday:A.visitorsToday,peopleNow:A.peopleNow,energyToday:A.energyToday,devicesOnline:A.devicesOnline,tick:()=>e(e=>({visitorsToday:e.visitorsToday+8+Math.round(Math.random()*20),peopleNow:Math.max(Math.round(A.peopleNow*.8),e.peopleNow+Math.round((Math.random()-.45)*200)),energyToday:e.energyToday+6+Math.round(Math.random()*12),devicesOnline:3850+Math.round(Math.random()*20)}))}));function L(e,t,n=!1){let r=(0,E.useRef)(e);(0,E.useEffect)(()=>{r.current=e},[e]),(0,E.useEffect)(()=>{if(t==null||t<=0)return;let e=performance.now(),i;n&&(r.current(),e=performance.now());function a(n){let o=n-e;for(;o>=t;)r.current(),o-=t,e+=t;i=requestAnimationFrame(a)}return i=requestAnimationFrame(a),()=>{i&&cancelAnimationFrame(i)}},[t,n])}var R=a(),He=D.find(e=>e.shape===`pearl`),Ue=He?[He.position[0],18,He.position[1]+2]:[0,18,-10];function We(){return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`hemisphereLight`,{args:[`#1d3f6e`,`#02060f`,.7]}),(0,R.jsx)(`ambientLight`,{intensity:1.1,color:`#9ec5ff`}),(0,R.jsx)(`directionalLight`,{intensity:1.8,position:[40,80,30],color:`#dceeff`}),(0,R.jsx)(`pointLight`,{intensity:900,distance:60,position:Ue,color:`#ff5fd6`}),(0,R.jsx)(`pointLight`,{intensity:700,distance:70,position:[6,10,12],color:`#ffb860`}),(0,R.jsx)(`pointLight`,{intensity:500,distance:60,position:[-22,10,12],color:`#ffb860`})]})}var Ge=p(d({uTime:0,uHeight:1,uSeed:0,uOpacity:1,uHighlight:0,uBottom:new x(`#0a2448`),uTop:new x(`#2f8de0`),uScan:new x(`#8fd3ff`),uWindow:new x(`#d9f3ff`),uFlood:0,uStripe:0},`
      varying vec3 vPos;
      varying vec3 vNormal;

      void main() {
        vPos = position;
        vNormal = normal;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,`
      uniform float uTime;
      uniform float uHeight;
      uniform float uSeed;
      uniform float uOpacity;
      uniform float uHighlight;
      uniform vec3 uBottom;
      uniform vec3 uTop;
      uniform vec3 uScan;
      uniform vec3 uWindow;
      uniform float uFlood;
      uniform float uStripe;

      varying vec3 vPos;
      varying vec3 vNormal;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }

      void main() {
        float h = clamp((vPos.y + uHeight * 0.5) / uHeight, 0.0, 1.0);
        vec3 col = mix(uBottom, uTop, pow(h, 1.3));

        // 侧面窗户
        float side = 1.0 - abs(vNormal.y);
        vec2 wc = abs(vNormal.x) > 0.5 ? vec2(vPos.z, vPos.y) : vec2(vPos.x, vPos.y);
        vec2 density = vec2(1.7, 1.5);
        vec2 cellId = floor(wc * density);
        vec2 cell = fract(wc * density);
        float wx = smoothstep(0.18, 0.3, cell.x) * (1.0 - smoothstep(0.7, 0.82, cell.x));
        float wy = smoothstep(0.2, 0.32, cell.y) * (1.0 - smoothstep(0.62, 0.74, cell.y));
        float win = wx * wy * side * step(0.03, h) * step(h, 0.95);
        float lit = step(0.5, hash(cellId + uSeed + floor(uTime * 0.12) * 0.37));
        col += uWindow * win * (0.12 + 0.4 * lit) * (1.0 - 0.45 * uFlood) * (1.0 - 0.5 * uStripe);

        // 泛光照明：檐口发光 + 立面柱廊竖向亮纹
        float cornice = smoothstep(0.86, 0.95, h) * (1.0 - step(0.985, h));
        col += uScan * cornice * 0.9 * uFlood;
        float pil = 1.0 - smoothstep(0.0, 0.06, abs(fract(wc.x * 0.5) - 0.5) - 0.44);
        col += uScan * pil * side * 0.18 * uFlood * (1.0 - h);

        // 螺旋灯带（上海中心）
        float ang = atan(vPos.z, vPos.x) / 6.2831853;
        float sp = fract(h * 7.0 - ang + uTime * 0.04);
        float stripe = smoothstep(0.0, 0.04, sp) * (1.0 - smoothstep(0.07, 0.12, sp));
        col += uScan * stripe * uStripe * 1.3 * side;

        // 扫光带
        float band = 0.12;
        float p = fract(uTime * 0.18 + uSeed) * (1.0 + 2.0 * band) - band;
        float scan = 1.0 - smoothstep(0.0, band, abs(h - p));
        col += uScan * scan * 0.45;

        // 顶面：泛光建筑的屋顶保持深色，让檐口灯带成为亮线
        if (vNormal.y > 0.5) {
          col = mix(mix(uTop, uScan, 0.4), uTop * 0.35, uFlood);
        }

        col += uScan * uHighlight * 0.45;

        gl_FragColor = vec4(col, uOpacity);
        #include <colorspace_fragment>
      }
    `)),Ke=p(d({uTime:0,uHeight:1,uSeed:0,uOpacity:1,uHighlight:0,uBottom:new x(`#4a1060`),uTop:new x(`#ff4fd8`),uScan:new x(`#ffb3f0`)},`
      varying vec3 vPos;
      varying vec3 vWorldNormal;
      varying vec3 vViewDir;

      void main() {
        vPos = position;
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldNormal = normalize(mat3(modelMatrix) * normal);
        vViewDir = normalize(cameraPosition - worldPos.xyz);
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,`
      uniform float uTime;
      uniform float uHeight;
      uniform float uSeed;
      uniform float uOpacity;
      uniform float uHighlight;
      uniform vec3 uBottom;
      uniform vec3 uTop;
      uniform vec3 uScan;

      varying vec3 vPos;
      varying vec3 vWorldNormal;
      varying vec3 vViewDir;

      void main() {
        float h = clamp((vPos.y + uHeight * 0.5) / uHeight, 0.0, 1.0);
        vec3 col = mix(uBottom, uTop, h);

        float fresnel = pow(1.0 - max(dot(normalize(vWorldNormal), normalize(vViewDir)), 0.0), 2.5);
        col += uScan * fresnel * 0.55;

        float band = 0.14;
        float p = fract(uTime * 0.18 + uSeed) * (1.0 + 2.0 * band) - band;
        float scan = 1.0 - smoothstep(0.0, band, abs(h - p));
        col += uScan * scan * 0.35;

        col += uScan * uHighlight * 0.45;

        gl_FragColor = vec4(col, uOpacity);
        #include <colorspace_fragment>
      }
    `)),qe=p(d({uColor:new x(`#8fc2ff`),uOpacity:1},`
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,`
      uniform vec3 uColor;
      uniform float uOpacity;
      varying vec2 vUv;

      void main() {
        float strength = 1.0 - abs(vUv.x - 0.5) * 2.0;
        strength = pow(strength, 2.0);
        float verticalFade = pow(sin(vUv.y * 3.14159), 0.5);
        float brightness = strength * verticalFade;
        gl_FragColor = vec4(uColor * brightness * 2.0, brightness * uOpacity);
      }
    `)),Je=p(d({uTime:0,uWarm:new x(`#ffc45e`),uCold:new x(`#7fb0ff`),uOpacity:.45,uScale:1},`
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,`
      uniform float uTime;
      uniform vec3 uWarm;
      uniform vec3 uCold;
      uniform float uOpacity;
      uniform float uScale;
      varying vec2 vUv;

      float hash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }

      float noise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);
        vec2 u = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
          mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
          u.y
        );
      }

      void main() {
        vec2 p = vec2(vUv.x * uScale, vUv.y);
        // 各向异性采样：亮斑沿江面横向拉成短条
        float n = noise(vec2(p.x * 9.0, p.y * 2.5) + vec2(uTime * 0.25, uTime * 0.08));
        n += 0.5 * noise(vec2(p.x * 20.0, p.y * 5.0) - vec2(uTime * 0.18, uTime * 0.3));
        n /= 1.5;
        float glint = smoothstep(0.62, 0.9, n);
        float edge = smoothstep(0.0, 0.08, vUv.y) * (1.0 - smoothstep(0.92, 1.0, vUv.y));
        // uv.y = 1 为浦东岸，uv.y = 0 为浦西岸
        vec3 c = mix(uWarm, uCold, smoothstep(0.25, 0.8, vUv.y));
        gl_FragColor = vec4(c, glint * uOpacity * edge);
      }
    `)),Ye=p(d({uTime:0,uSeed:0,uOpacity:1},`
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,`
      uniform float uTime;
      uniform float uSeed;
      uniform float uOpacity;
      varying vec2 vUv;

      void main() {
        vec2 grid = vec2(26.0, 56.0);
        vec2 cell = fract(vUv * grid);
        float px = smoothstep(0.08, 0.22, cell.x) * (1.0 - smoothstep(0.78, 0.92, cell.x))
                 * smoothstep(0.08, 0.22, cell.y) * (1.0 - smoothstep(0.78, 0.92, cell.y));
        float t = uTime * 0.12 + uSeed * 7.0;
        float band = sin((vUv.x * 1.5 + vUv.y * 2.5 + t) * 6.2831853) * 0.5 + 0.5;
        float wave = sin((vUv.y * 3.0 - t * 1.4) * 6.2831853) * 0.5 + 0.5;
        vec3 c1 = vec3(0.1, 0.55, 1.0);
        vec3 c2 = vec3(1.0, 0.25, 0.65);
        vec3 c3 = vec3(0.15, 1.0, 0.7);
        vec3 col = mix(mix(c1, c2, band), c3, smoothstep(0.35, 0.95, wave) * 0.6);
        float scanline = 0.85 + 0.15 * sin(vUv.y * 320.0 + uTime * 3.0);
        gl_FragColor = vec4(col * (0.3 + 0.7 * px) * scanline * 1.35, uOpacity);
      }
    `)),Xe=p(d({uColor:new x(`#cfe9ff`),uOpacity:.12},`
      varying vec2 vUv;
      varying vec3 vWorldNormal;
      varying vec3 vViewDir;
      void main() {
        vUv = uv;
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldNormal = normalize(mat3(modelMatrix) * normal);
        vViewDir = normalize(cameraPosition - worldPos.xyz);
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,`
      uniform vec3 uColor;
      uniform float uOpacity;
      varying vec2 vUv;
      varying vec3 vWorldNormal;
      varying vec3 vViewDir;
      void main() {
        float core = pow(abs(dot(normalize(vWorldNormal), normalize(vViewDir))), 1.6);
        float a = pow(vUv.y, 1.4) * core * uOpacity;
        gl_FragColor = vec4(uColor, a);
      }
    `)),Ze=p(d({uHorizon:new x(`#1b1744`),uZenith:new x(`#020812`)},`
      varying vec3 vW;
      void main() {
        vW = (modelMatrix * vec4(position, 1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,`
      uniform vec3 uHorizon;
      uniform vec3 uZenith;
      varying vec3 vW;
      void main() {
        float h = normalize(vW).y;
        float t = smoothstep(-0.02, 0.32, h);
        gl_FragColor = vec4(mix(uHorizon, uZenith, t), 1.0);
      }
    `));function Qe(){return(0,R.jsxs)(`mesh`,{raycast:()=>null,children:[(0,R.jsx)(`sphereGeometry`,{args:[450,24,12]}),(0,R.jsx)(Ze,{side:1,depthWrite:!1,uHorizon:`#1b1744`,uZenith:w.bg})]})}var $e=`/assets/ring-x4VHOqO6.png`;function et(){let e=(0,E.useRef)(null),t=ne($e),[n,r]=Ae,[i,a]=k,o=(0,E.useMemo)(()=>{let e=i.z[0]+r/2;return{geo:new h(n,.4,e),z:i.z[0]-e/2}},[n,r,i]),s=(0,E.useMemo)(()=>{let e=r/2-i.z[1],t=i.z[1]+e/2,o=a.x[0]+n/2,s=n/2-a.x[1];return{left:{geo:new h(o,.4,e),x:-n/2+o/2,z:t},right:{geo:new h(s,.4,e),x:n/2-s/2,z:t}}},[n,r,i,a]);(0,E.useEffect)(()=>()=>{o.geo.dispose(),s.left.geo.dispose(),s.right.geo.dispose()},[o,s]),y((t,n)=>{e.current.rotation.z+=n/8});let c=[{geo:o.geo,x:0,z:o.z},{geo:s.left.geo,x:s.left.x,z:s.left.z},{geo:s.right.geo,x:s.right.x,z:s.right.z}];return(0,R.jsxs)(`group`,{children:[(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,"position-y":-.3,children:[(0,R.jsx)(`planeGeometry`,{args:[600,600]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#03101f`,roughness:1})]}),c.map((e,t)=>(0,R.jsxs)(`group`,{position:[e.x,-.2,e.z],children:[(0,R.jsx)(`mesh`,{geometry:e.geo,children:(0,R.jsx)(`meshStandardMaterial`,{color:`#061a33`,roughness:.9,metalness:.2})}),(0,R.jsxs)(`lineSegments`,{raycast:()=>null,children:[(0,R.jsx)(`edgesGeometry`,{args:[e.geo]}),(0,R.jsx)(`lineBasicMaterial`,{color:w.primary,transparent:!0,opacity:.7})]})]},t)),(0,R.jsxs)(`mesh`,{position:[(a.x[0]-n/2)/2,.07,i.z[1]+1],children:[(0,R.jsx)(`boxGeometry`,{args:[a.x[0]+n/2,.14,2]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#0f2d55`,roughness:.8})]}),(0,R.jsxs)(`mesh`,{position:[0,.05,i.z[0]-.8],children:[(0,R.jsx)(`boxGeometry`,{args:[n,.1,1.6]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#0c2749`,roughness:.8})]}),(0,R.jsx)(l,{infiniteGrid:!0,"position-y":-.28,cellSize:2,sectionSize:10,cellThickness:.6,sectionThickness:1.2,cellColor:`#0b2b4d`,sectionColor:`#174a7d`,fadeDistance:260,fadeStrength:1.6}),(0,R.jsxs)(`mesh`,{ref:e,"rotation-x":-Math.PI/2,"position-y":-.27,raycast:()=>null,children:[(0,R.jsx)(`planeGeometry`,{args:[110,110]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,map:t,color:w.glow,opacity:1,depthWrite:!1,blending:2})]})]})}function tt(){let e=(0,E.useRef)(null),[t,n]=k,r=t.x[1]-t.x[0]+12,i=t.z[1]-t.z[0],a=(t.x[0]+t.x[1])/2,o=(t.z[0]+t.z[1])/2,s=n.x[1]-n.x[0],c=n.z[1]-n.z[0],l=(n.x[0]+n.x[1])/2,u=(n.z[0]+n.z[1])/2;return y((t,n)=>{e.current.uniforms.uTime.value+=n}),(0,R.jsxs)(`group`,{children:[(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,position:[a,-.16,o],children:[(0,R.jsx)(`planeGeometry`,{args:[r,i]}),(0,R.jsx)(ee,{blur:[240,80],resolution:1024,mixBlur:1,mixStrength:1.4,mirror:.95,depthScale:0,color:`#8fa6bd`,metalness:.4,roughness:.35})]}),(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,position:[a,-.1,o],raycast:()=>null,children:[(0,R.jsx)(`planeGeometry`,{args:[r,i]}),(0,R.jsx)(Je,{ref:e,transparent:!0,depthWrite:!1,blending:2,uOpacity:.45,uScale:r/i})]}),(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,position:[l,-.16,u],children:[(0,R.jsx)(`planeGeometry`,{args:[s,c]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#071d3a`,metalness:.6,roughness:.35})]})]})}function nt(){return(0,R.jsx)(`group`,{children:Pe.map((e,t)=>{let{from:n,to:r,width:i=2.6}=e,a=r[0]-n[0],o=r[1]-n[1],s=Math.hypot(a,o),c=Math.atan2(a,o),l=(n[0]+r[0])/2,u=(n[1]+r[1])/2,d=s/2+i/2;return(0,R.jsxs)(`group`,{position:[l,.01,u],"rotation-y":c,children:[(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,children:[(0,R.jsx)(`planeGeometry`,{args:[i,s+i]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#0a1c33`,roughness:1})]}),(0,R.jsx)(_,{points:[[0,.02,-s/2],[0,.02,s/2]],color:w.primary,lineWidth:1,dashed:!0,dashSize:1.2,gapSize:.9,transparent:!0,opacity:.6}),(0,R.jsx)(_,{points:[[-i/2,.02,-d],[-i/2,.02,d]],color:`#1d4f7f`,lineWidth:1}),(0,R.jsx)(_,{points:[[i/2,.02,-d],[i/2,.02,d]],color:`#1d4f7f`,lineWidth:1})]},t)})})}function rt(){let{x:e,z:t,span:n,width:r}=Ne,i=n/2,a=(0,E.useMemo)(()=>[-.8,-.4,0,.4,.8].map(e=>({dx:e*i,h:Math.sqrt(Math.max(i*i-(e*i)**2,.1))})),[i]),o=(0,E.useMemo)(()=>Array.from({length:15},(e,t)=>{let n=t/14*Math.PI;return[Math.cos(n)*i,Math.sin(n)*i]}),[i]),s=(0,R.jsx)(`meshStandardMaterial`,{color:`#c9d8ff`,emissive:`#5ad8ff`,emissiveIntensity:.45,roughness:.4,metalness:.6});return(0,R.jsxs)(`group`,{position:[e,-.37,t],children:[(0,R.jsxs)(`mesh`,{"position-y":.28,children:[(0,R.jsx)(`boxGeometry`,{args:[n+1,.2,r]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#13284a`,roughness:.9})]}),[-1,1].map(e=>(0,R.jsxs)(`mesh`,{position:[e*(n/2+.3),-.05,0],children:[(0,R.jsx)(`boxGeometry`,{args:[.6,.6,r+.4]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#1b355f`,roughness:.9})]},e)),[-1,1].map(e=>(0,R.jsxs)(`group`,{position:[0,.38,e*r/2],children:[(0,R.jsxs)(`mesh`,{children:[(0,R.jsx)(`torusGeometry`,{args:[i,.09,8,32,Math.PI]}),s]}),a.map((e,t)=>(0,R.jsxs)(`mesh`,{position:[e.dx,e.h/2,0],children:[(0,R.jsx)(`boxGeometry`,{args:[.06,e.h,.06]}),s]},t)),(0,R.jsxs)(`mesh`,{"position-y":i*.5,children:[(0,R.jsx)(`boxGeometry`,{args:[n*.72,.06,.06]}),s]}),(0,R.jsxs)(g,{limit:o.length,range:o.length,children:[(0,R.jsx)(`sphereGeometry`,{args:[.09,8,6]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#fff6d6`}),o.map(([e,t],n)=>(0,R.jsx)(b,{position:[e,t,0]},n))]})]},e))]})}var z=null;function B(){if(z)return z;let e=document.createElement(`canvas`);e.width=e.height=128;let t=e.getContext(`2d`),n=t.createRadialGradient(128/2,128/2,0,128/2,128/2,128/2);return n.addColorStop(0,`rgba(255,255,255,1)`),n.addColorStop(.35,`rgba(255,255,255,0.4)`),n.addColorStop(1,`rgba(255,255,255,0)`),t.fillStyle=n,t.fillRect(0,0,128,128),z=new m(e),z.colorSpace=s,z}var it=`#ffd58a`;function at(){let e=[];return je.forEach(t=>{let n=t.to[0]-t.from[0],r=t.to[1]-t.from[1],i=Math.hypot(n,r),a=Math.floor(i/t.step);for(let o=0;o<=a;o++){let a=o*t.step/i;e.push([t.from[0]+n*a,t.from[1]+r*a])}}),e}function ot(){let e=(0,E.useMemo)(at,[]),t=B(),n=2.2,[r,i]=k,a=i.x[1]+.5,o=r.x[1]-2;return(0,R.jsxs)(`group`,{raycast:()=>null,children:[(0,R.jsxs)(`mesh`,{position:[(a+o)/2,.2,r.z[1]-.05],children:[(0,R.jsx)(`boxGeometry`,{args:[o-a,.08,.12]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ffd58a`})]}),(0,R.jsxs)(`mesh`,{position:[(a+o)/2,.21,r.z[1]-.05],children:[(0,R.jsx)(`boxGeometry`,{args:[o-a,.5,.9]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,color:it,opacity:.12,depthWrite:!1,blending:2})]}),(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`cylinderGeometry`,{args:[.04,.06,n,6]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#2a3a55`,roughness:.8,metalness:.4}),e.map(([e,t],r)=>(0,R.jsx)(b,{position:[e,n/2,t]},r))]}),(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`sphereGeometry`,{args:[.14,10,8]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#fff2c8`}),e.map(([e,t],r)=>(0,R.jsx)(b,{position:[e,n+.08,t]},r))]}),(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`sphereGeometry`,{args:[.8,10,8]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,color:it,opacity:.3,depthWrite:!1,blending:2}),e.map(([e,t],r)=>(0,R.jsx)(b,{position:[e,n+.08,t]},r))]}),(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`planeGeometry`,{args:[4.5,4.5]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,map:t,color:it,opacity:.45,depthWrite:!1,blending:2}),e.map(([e,t],n)=>(0,R.jsx)(b,{position:[e,.03,t],rotation:[-Math.PI/2,0,0]},n))]})]})}var st=70;function ct(){let e=(0,E.useRef)(null),t=F(e=>e.beam);return y(t=>{let n=t.clock.elapsedTime;e.current.children.forEach((e,t)=>{e.rotation.z=Math.sin(n*.22+t*2.1)*.55,e.rotation.x=-.35+Math.sin(n*.17+t*1.3)*.3})}),(0,R.jsx)(`group`,{ref:e,visible:t,raycast:()=>null,children:Me.map(([e,t],n)=>(0,R.jsxs)(`group`,{position:[e,.3,t],children:[(0,R.jsxs)(`mesh`,{"position-y":st/2,"rotation-x":Math.PI,children:[(0,R.jsx)(`coneGeometry`,{args:[1.4,st,16,1,!0]}),(0,R.jsx)(Xe,{transparent:!0,depthWrite:!1,side:2,blending:2,uColor:`#fff1cc`,uOpacity:.24})]}),(0,R.jsxs)(`mesh`,{children:[(0,R.jsx)(`sphereGeometry`,{args:[.35,10,8]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ffffff`,toneMapped:!1})]}),(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,"position-y":-.2,children:[(0,R.jsx)(`planeGeometry`,{args:[2.6,2.6]}),(0,R.jsx)(`meshBasicMaterial`,{map:B(),color:`#fff1cc`,transparent:!0,opacity:.5,depthWrite:!1,blending:2,toneMapped:!1})]})]},n))})}function lt(e){return()=>{e|=0,e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function ut(e,t,[n,r],[i,a]){let o=i-n,s=a-r,c=o*o+s*s||1,l=Math.max(0,Math.min(1,((e-n)*o+(t-r)*s)/c));return Math.hypot(e-(n+o*l),t-(r+s*l))}var dt=(e,t)=>Pe.some(n=>ut(e,t,n.from,n.to)<(n.width??2.4)/2+.7),ft=[...D,...ke],pt=(e,t)=>ft.some(n=>Math.abs(e-n.position[0])<n.size[0]/2+1&&Math.abs(t-n.position[1])<n.size[2]/2+1),mt=(e,t)=>k.some(n=>e>=n.x[0]-.6&&e<=n.x[1]+.6&&t>=n.z[0]-.6&&t<=n.z[1]+.6),ht=(e,t)=>pt(e,t)||dt(e,t)||mt(e,t);function gt(){let e=lt(20261009),t=[],[n,r]=Ae,i=n/2-1,a=r/2-1;Pe.forEach(n=>{let r=n.to[0]-n.from[0],o=n.to[1]-n.from[1],s=Math.hypot(r,o),c=r/s,l=o/s,u=-l,d=c,f=(n.width??2.4)/2+1;for(let r=1.5;r<s-1;r+=2.6)for(let o of[-1,1]){let s=n.from[0]+c*r+u*o*f,p=n.from[1]+l*r+d*o*f;Math.abs(s)>i||Math.abs(p)>a||ht(s,p)||t.push({x:s+(e()-.5)*.5,z:p+(e()-.5)*.5,s:.75+e()*.5})}});for(let n=0;n<90;n++){let n=-4+(e()-.5)*20,r=-11+(e()-.5)*7;ht(n,r)||t.push({x:n,z:r,s:.6+e()*.6})}for(let n=0;n<60;n++){let n=(e()-.5)*80,r=-8.6+(e()-.5)*1.6;ht(n,r)||t.push({x:n,z:r,s:.6+e()*.5})}return t}function _t(){let e=(0,E.useMemo)(gt,[]);return(0,R.jsxs)(`group`,{children:[(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`cylinderGeometry`,{args:[.08,.13,.8,5]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#4a3320`,roughness:1}),e.map((e,t)=>(0,R.jsx)(b,{position:[e.x,.4*e.s,e.z],scale:e.s},t))]}),(0,R.jsxs)(g,{limit:e.length,range:e.length,children:[(0,R.jsx)(`coneGeometry`,{args:[.55,1.5,6]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#1f7a4d`,emissive:`#0b4a2c`,emissiveIntensity:.6,roughness:.9,flatShading:!0}),e.map((e,t)=>(0,R.jsx)(b,{position:[e.x,1.55*e.s,e.z],scale:e.s},t))]})]})}function vt(e){let[t,n,r]=e.size;switch(e.shape){case`dome`:return n*.8+n*.18+t*.2*1.15;case`clock`:return n*.55+n*.45+n*.16+n*.06;case`globe`:return n+r*.5*.75+r*.5;case`pyramid`:return n*.82+n*.28;case`jinmao`:return n*.96+n*.12;case`twist`:return n*.45;default:return n}}var V=()=>null,yt=new i(0,1,0);function H({h:e,colors:t,seed:n,flood:r,stripe:i}){return(0,R.jsx)(Ge,{transparent:!0,uHeight:e,uSeed:n,uBottom:t[0],uTop:t[1],uScan:t[2],uWindow:t[3],uFlood:r?1:0,uStripe:i?1:0})}function U({h:e,colors:t,seed:n}){return(0,R.jsx)(Ke,{transparent:!0,uHeight:e,uSeed:n,uBottom:t[0],uTop:t[1],uScan:t[2]})}var bt=e=>Oe.includes(e.type),xt=(e,t)=>t?[e[1],e[0],e[2],e[3]]:e;function W({w:e,d:t,y:n,color:r}){let i=.14;return(0,R.jsxs)(`group`,{"position-y":n,raycast:V,children:[(0,R.jsxs)(`mesh`,{"position-z":t/2,children:[(0,R.jsx)(`boxGeometry`,{args:[e+.3,i,i]}),(0,R.jsx)(`meshBasicMaterial`,{color:r})]}),(0,R.jsxs)(`mesh`,{"position-z":-t/2,children:[(0,R.jsx)(`boxGeometry`,{args:[e+.3,i,i]}),(0,R.jsx)(`meshBasicMaterial`,{color:r})]}),(0,R.jsxs)(`mesh`,{"position-x":e/2,children:[(0,R.jsx)(`boxGeometry`,{args:[i,i,t+.3]}),(0,R.jsx)(`meshBasicMaterial`,{color:r})]}),(0,R.jsxs)(`mesh`,{"position-x":-e/2,children:[(0,R.jsx)(`boxGeometry`,{args:[i,i,t+.3]}),(0,R.jsx)(`meshBasicMaterial`,{color:r})]})]})}function G(e,t){let n=(0,E.useMemo)(e,t);return(0,E.useEffect)(()=>()=>n.dispose(),[n]),n}function St({w:e,h:t,d:n,seed:r}){return(0,R.jsxs)(`mesh`,{position:[0,t*.52,n/2+.03],raycast:V,children:[(0,R.jsx)(`planeGeometry`,{args:[e*.86,t*.72]}),(0,R.jsx)(Ye,{uSeed:r,toneMapped:!1,transparent:!0,depthWrite:!1})]})}function Ct({y:e,phase:t}){let n=(0,E.useRef)(null),r=(0,E.useRef)(null);return y(e=>{let i=Math.sin(e.clock.elapsedTime*2.2+t)>.2;n.current.material.opacity=i?1:.15,n.current.scale.setScalar(i?1.3:.8),r.current.material.opacity=i?.9:.1}),(0,R.jsxs)(`group`,{"position-y":e+.35,raycast:V,children:[(0,R.jsxs)(`mesh`,{ref:n,raycast:V,children:[(0,R.jsx)(`sphereGeometry`,{args:[.22,8,6]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ff2a3a`,transparent:!0,toneMapped:!1})]}),(0,R.jsx)(`sprite`,{ref:r,scale:[1.8,1.8,1],raycast:V,children:(0,R.jsx)(`spriteMaterial`,{map:B(),color:`#ff3b4a`,transparent:!0,depthWrite:!1,blending:2,toneMapped:!1})})]})}function wt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=G(()=>new h(r,i,a),[r,i,a]),s=bt(e);return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":i/2,geometry:o,children:(0,R.jsx)(H,{h:i,colors:t,seed:n,flood:s})}),(0,R.jsxs)(`lineSegments`,{"position-y":i/2,raycast:V,children:[(0,R.jsx)(`edgesGeometry`,{args:[o]}),(0,R.jsx)(`lineBasicMaterial`,{color:t[2],transparent:!0,opacity:.5})]}),s&&(0,R.jsx)(W,{w:r,d:a,y:i+.05,color:t[2]}),e.screen&&(0,R.jsx)(St,{w:r,h:i,d:a,seed:n})]})}function Tt({data:e,colors:t,seed:r}){let[a,o]=e.size,s=o*.3,c=(0,E.useMemo)(()=>[0,1,2].map(e=>{let t=e/3*Math.PI*2+Math.PI/6,r=new i(Math.cos(t)*a*.4,0,Math.sin(t)*a*.4),o=new i(Math.cos(t)*.5,s,Math.sin(t)*.5),c=new i().subVectors(o,r),l=c.length();return{q:new n().setFromUnitVectors(yt,c.normalize()),mid:new i().addVectors(r,o).multiplyScalar(.5),len:l}}),[a,s]),l=a*.55,u=a*.3;return(0,R.jsxs)(R.Fragment,{children:[c.map((e,n)=>(0,R.jsxs)(`mesh`,{position:e.mid,quaternion:e.q,children:[(0,R.jsx)(`cylinderGeometry`,{args:[.22,.3,e.len,8]}),(0,R.jsx)(U,{h:e.len,colors:t,seed:r+n*.1})]},n)),[0,1,2].map(e=>{let n=e/3*Math.PI*2+Math.PI/6;return(0,R.jsxs)(`mesh`,{position:[Math.cos(n)*1.1,s,Math.sin(n)*1.1],children:[(0,R.jsx)(`sphereGeometry`,{args:[.55,16,12]}),(0,R.jsx)(U,{h:1.1,colors:t,seed:r})]},`s${e}`)}),(0,R.jsxs)(`mesh`,{"position-y":o*.39,children:[(0,R.jsx)(`cylinderGeometry`,{args:[.45,.55,o*.78,12]}),(0,R.jsx)(U,{h:o*.78,colors:t,seed:r})]}),(0,R.jsxs)(`mesh`,{"position-y":o*.34,children:[(0,R.jsx)(`sphereGeometry`,{args:[l,32,24]}),(0,R.jsx)(U,{h:l*2,colors:t,seed:r+.3})]}),(0,R.jsxs)(`mesh`,{"position-y":o*.66,children:[(0,R.jsx)(`sphereGeometry`,{args:[u,24,18]}),(0,R.jsx)(U,{h:u*2,colors:t,seed:r+.5})]}),(0,R.jsxs)(`mesh`,{"position-y":o*.85,children:[(0,R.jsx)(`sphereGeometry`,{args:[.65,16,12]}),(0,R.jsx)(U,{h:1.3,colors:t,seed:r+.7})]}),(0,R.jsxs)(`mesh`,{"position-y":o*.89,children:[(0,R.jsx)(`cylinderGeometry`,{args:[.06,.12,o*.22,8]}),(0,R.jsx)(U,{h:o*.22,colors:t,seed:r})]})]})}function Et(e,t){let n=new se(e*.55,e,t,36,48,!1),r=n.attributes.position,a=new i;for(let e=0;e<r.count;e++){a.fromBufferAttribute(r,e);let n=(a.y+t/2)/t,i=Math.atan2(a.z,a.x),o=Math.hypot(a.x,a.z)*(1+.16*Math.cos(3*i)),s=n*Math.PI*.66;r.setXYZ(e,o*Math.cos(i+s),a.y,o*Math.sin(i+s))}return r.needsUpdate=!0,n.computeVertexNormals(),n}function Dt({data:e,colors:t,seed:n}){let[r,i]=e.size,a=G(()=>Et(r/2,i),[r,i]);return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":i/2,geometry:a,children:(0,R.jsx)(H,{h:i,colors:t,seed:n,stripe:!0})}),(0,R.jsxs)(`mesh`,{"position-y":i-.45,"rotation-x":Math.PI/2,raycast:V,children:[(0,R.jsx)(`torusGeometry`,{args:[r*.33,.12,8,36]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#eaf8ff`,toneMapped:!1})]}),(0,R.jsx)(`sprite`,{"position-y":i-.3,scale:[3,3,1],raycast:V,children:(0,R.jsx)(`spriteMaterial`,{map:B(),color:`#bfe8ff`,transparent:!0,opacity:.6,depthWrite:!1,blending:2,toneMapped:!1})})]})}function Ot(e,t,n){let r=new h(e,t,n,1,24,1),i=r.attributes.position;for(let e=0;e<i.count;e++){let n=(i.getY(e)+t/2)/t;i.setZ(e,i.getZ(e)*(1-.88*n)),i.setX(e,i.getX(e)*(1-.12*n))}return i.needsUpdate=!0,r.computeVertexNormals(),r}function kt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=G(()=>Ot(r,i,a),[r,i,a]);return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":i/2,geometry:o,children:(0,R.jsx)(H,{h:i,colors:t,seed:n})}),(0,R.jsxs)(`mesh`,{"position-y":i*.9,raycast:V,children:[(0,R.jsx)(`boxGeometry`,{args:[r*.42,i*.09,a*.5]}),(0,R.jsx)(`meshBasicMaterial`,{color:w.bg})]}),[1,-1].map(e=>(0,R.jsxs)(`mesh`,{position:[0,i*.9,e*(a*.25-.06)],raycast:V,children:[(0,R.jsx)(`boxGeometry`,{args:[r*.56,i*.13,.08]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#eaf6ff`,toneMapped:!1})]},e)),(0,R.jsxs)(`mesh`,{"position-y":i+.05,raycast:V,children:[(0,R.jsx)(`boxGeometry`,{args:[r*.88,.12,.3]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#eaf6ff`,toneMapped:!1})]})]})}var At=[.3,.19,.14,.11,.08,.06,.045,.035];function jt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=(0,E.useMemo)(()=>{let e=0;return At.map((t,n)=>{let o=i*t,s=1-n*.085,c={y:e+o/2,th:o,tw:r*s,td:a*s};return e+=o,c})},[r,i,a]),s=o[o.length-1],c=s.y+s.th/2;return(0,R.jsxs)(R.Fragment,{children:[o.map((e,r)=>(0,R.jsxs)(`group`,{children:[(0,R.jsxs)(`mesh`,{"position-y":e.y,children:[(0,R.jsx)(`boxGeometry`,{args:[e.tw,e.th,e.td]}),(0,R.jsx)(H,{h:e.th,colors:t,seed:n+r*.07})]}),(0,R.jsx)(W,{w:e.tw,d:e.td,y:e.y+e.th/2,color:t[2]})]},r)),(0,R.jsxs)(`mesh`,{"position-y":c+i*.06,raycast:V,children:[(0,R.jsx)(`coneGeometry`,{args:[r*.12,i*.12,8]}),(0,R.jsx)(U,{h:i*.12,colors:t,seed:n})]})]})}function Mt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=i*.8,s=G(()=>new h(r,o,a),[r,o,a]),c=r*.2;return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":o/2,geometry:s,children:(0,R.jsx)(H,{h:o,colors:t,seed:n,flood:!0})}),(0,R.jsxs)(`lineSegments`,{"position-y":o/2,raycast:V,children:[(0,R.jsx)(`edgesGeometry`,{args:[s]}),(0,R.jsx)(`lineBasicMaterial`,{color:t[2],transparent:!0,opacity:.5})]}),(0,R.jsx)(W,{w:r,d:a,y:o+.05,color:t[2]}),(0,R.jsxs)(`mesh`,{"position-y":o+i*.09,children:[(0,R.jsx)(`cylinderGeometry`,{args:[c,c,i*.18,20]}),(0,R.jsx)(U,{h:i*.18,colors:xt(t,!0),seed:n})]}),(0,R.jsxs)(`mesh`,{"position-y":o+i*.18,children:[(0,R.jsx)(`sphereGeometry`,{args:[c*1.15,24,12,0,Math.PI*2,0,Math.PI/2]}),(0,R.jsx)(U,{h:c*2.3,colors:xt(t,!0),seed:n+.4})]})]})}function Nt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=i*.55,s=i*.45,c=r*.42,l=a*.55,u=o+s*.8,d=c*.3,f=[{pos:[0,u,l/2+.02],rot:[0,0,0]},{pos:[0,u,-l/2-.02],rot:[0,Math.PI,0]},{pos:[c/2+.02,u,0],rot:[0,Math.PI/2,0]},{pos:[-c/2-.02,u,0],rot:[0,-Math.PI/2,0]}],p=G(()=>new h(r,o,a),[r,o,a]);return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":o/2,geometry:p,children:(0,R.jsx)(H,{h:o,colors:t,seed:n,flood:!0})}),(0,R.jsxs)(`lineSegments`,{"position-y":o/2,raycast:V,children:[(0,R.jsx)(`edgesGeometry`,{args:[p]}),(0,R.jsx)(`lineBasicMaterial`,{color:t[2],transparent:!0,opacity:.5})]}),(0,R.jsxs)(`mesh`,{position:[0,o+s/2,0],children:[(0,R.jsx)(`boxGeometry`,{args:[c,s,l]}),(0,R.jsx)(H,{h:s,colors:t,seed:n+.2,flood:!0})]}),f.map((e,t)=>(0,R.jsxs)(`mesh`,{position:e.pos,rotation:e.rot,raycast:V,children:[(0,R.jsx)(`circleGeometry`,{args:[d,24]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#fff4c2`})]},t)),(0,R.jsxs)(`mesh`,{"position-y":o+s+i*.05,raycast:V,children:[(0,R.jsx)(`boxGeometry`,{args:[c*.7,i*.1,l*.7]}),(0,R.jsx)(H,{h:i*.1,colors:t,seed:n+.3,flood:!0})]}),(0,R.jsxs)(`mesh`,{"position-y":o+s+i*.16,raycast:V,children:[(0,R.jsx)(`coneGeometry`,{args:[c*.25,i*.12,8]}),(0,R.jsx)(U,{h:i*.12,colors:xt(t,!0),seed:n})]}),(0,R.jsx)(W,{w:r,d:a,y:o+.05,color:t[2]})]})}function Pt({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=i*.82,s=G(()=>new h(r,o,a),[r,o,a]),c=(0,E.useMemo)(()=>{let n=new x(e.accent??t[1]);return[n.clone().multiplyScalar(.35),n,n.clone().lerp(new x(`#ffffff`),.4),t[3]]},[e.accent,t]);return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":o/2,geometry:s,children:(0,R.jsx)(H,{h:o,colors:t,seed:n,flood:bt(e)})}),(0,R.jsxs)(`lineSegments`,{"position-y":o/2,raycast:V,children:[(0,R.jsx)(`edgesGeometry`,{args:[s]}),(0,R.jsx)(`lineBasicMaterial`,{color:t[2],transparent:!0,opacity:.5})]}),(0,R.jsxs)(`mesh`,{"position-y":o+i*.14,"rotation-y":Math.PI/4,raycast:V,children:[(0,R.jsx)(`coneGeometry`,{args:[Math.max(r,a)*.72,i*.28,4]}),(0,R.jsx)(U,{h:i*.28,colors:c,seed:n})]}),bt(e)&&(0,R.jsx)(W,{w:r,d:a,y:o+.05,color:t[2]})]})}function Ft({data:e,colors:t,seed:n}){let[r,i,a]=e.size,o=G(()=>new h(r,i,a),[r,i,a]),s=a*.5,c=a*.38;return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`mesh`,{"position-y":i/2,geometry:o,children:(0,R.jsx)(H,{h:i,colors:t,seed:n})}),(0,R.jsxs)(`lineSegments`,{"position-y":i/2,raycast:V,children:[(0,R.jsx)(`edgesGeometry`,{args:[o]}),(0,R.jsx)(`lineBasicMaterial`,{color:t[2],transparent:!0,opacity:.5})]}),(0,R.jsxs)(`mesh`,{position:[-r*.25,i+s*.75,0],children:[(0,R.jsx)(`sphereGeometry`,{args:[s,28,20]}),(0,R.jsx)(U,{h:s*2,colors:t,seed:n+.2})]}),(0,R.jsxs)(`mesh`,{position:[r*.3,i+c*.75,0],children:[(0,R.jsx)(`sphereGeometry`,{args:[c,24,18]}),(0,R.jsx)(U,{h:c*2,colors:t,seed:n+.6})]})]})}var It={box:wt,pearl:Tt,twist:Dt,swfc:kt,jinmao:jt,dome:Mt,clock:Nt,pyramid:Pt,globe:Ft};function Lt(e){let t=It[e.data.shape??`box`];return(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(t,{...e}),e.data.beacon&&(0,R.jsx)(Ct,{y:vt(e.data),phase:e.seed*6})]})}var Rt=S.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 13px;
  line-height: 1.25;
  white-space: nowrap;
  color: ${w.text};
  background: ${({$active:e})=>e?`rgba(63, 182, 255, 0.35)`:`rgba(4, 16, 36, 0.72)`};
  border: 1px solid
    ${({$active:e})=>e?w.glow:`rgba(63, 182, 255, 0.45)`};
  box-shadow: ${({$active:e})=>e?`0 0 14px ${w.primary}`:`none`};
  backdrop-filter: blur(4px);
  transform-origin: 50% 100%;
  transition: background 0.2s, box-shadow 0.2s;

  &::after {
    content: "";
    position: absolute;
    left: 50%;
    top: 100%;
    width: 1px;
    height: 10px;
    background: linear-gradient(to bottom, ${w.primary}, transparent);
  }
`,zt=S.span`
  font-size: 11px;
  color: ${w.textMuted};
  letter-spacing: 1px;
`,Bt=S.div`
  display: grid;
  grid-template-columns: auto auto;
  gap: 2px 10px;
  margin-top: 2px;
  padding-top: 4px;
  border-top: 1px dashed rgba(255, 255, 255, 0.25);
  font-size: 12px;
  color: ${w.textMuted};

  b {
    color: ${w.glow};
    font-weight: 600;
  }
`;function Vt({building:e,active:t}){let n=F(e=>e.sceneReady&&e.labels),r=v(e=>e.size);if(!n||!(e.label||t))return null;let i=Math.min(r.width/1920,r.height/1080);return(0,R.jsx)(ie,{center:!0,position:[0,vt(e)+1.2,0],zIndexRange:[t?60:40,0],style:{pointerEvents:`none`},children:(0,R.jsxs)(Rt,{$active:t,style:{transform:`translateY(-50%) scale(${i})`},children:[(0,R.jsx)(`strong`,{children:e.name}),(0,R.jsxs)(zt,{children:[Ee[e.type],` · `,e.height,` m`]}),t&&(0,R.jsxs)(Bt,{children:[(0,R.jsxs)(`span`,{children:[`建成 `,(0,R.jsx)(`b`,{children:e.builtYear}),` 年`]}),(0,R.jsxs)(`span`,{children:[`楼层 `,(0,R.jsx)(`b`,{children:e.floors}),` 层`]}),(0,R.jsxs)(`span`,{children:[`在场 `,(0,R.jsx)(`b`,{children:e.people.toLocaleString()}),` 人`]}),(0,R.jsxs)(`span`,{children:[`今日用电 `,(0,R.jsx)(`b`,{children:e.energyToday.toLocaleString()}),` kWh`]})]})]})})}function Ht(e){let t=0;for(let n=0;n<e.length;n++)t=(t*31+e.charCodeAt(n))%1e3;return t/1e3}var Ut=new Map;function Wt(e){let t=Ut.get(e);return t||(t=De[e].map(e=>new x(e)),Ut.set(e,t)),t}function Gt(e,t){let n=.74+.14*Math.sin(t*.25);e[0].setHSL(n,.85,.12,s),e[1].setHSL(n,1,.5,s),e[2].setHSL(n,.9,.72,s)}function Kt(e,t,n,r,i){e.traverse(e=>{let a=e.material?.uniforms;a?.uTime&&(a.uTime.value+=t,i&&a.uBottom&&a.uTop&&a.uScan&&(a.uBottom.value.copy(i[0]),a.uTop.value.copy(i[1]),a.uScan.value.copy(i[2])),a.uHighlight&&(a.uHighlight.value=u.lerp(a.uHighlight.value,n,.12)),a.uOpacity&&(a.uOpacity.value=u.lerp(a.uOpacity.value,r,.1)))})}function qt(){let e=(0,E.useRef)(null);return(0,E.useLayoutEffect)(()=>{let t=e.current.children.map(e=>e.scale),n=C.timeline({delay:.9});return n.fromTo(t,{y:.001},{y:1,duration:1.1,ease:`back.out(1.3)`,stagger:.04}),()=>{n.kill()}},[]),(0,R.jsxs)(R.Fragment,{children:[(0,R.jsx)(`group`,{ref:e,children:D.map(e=>(0,R.jsx)(Jt,{data:e},e.id))}),(0,R.jsx)(Yt,{})]})}function Jt({data:e}){let[t,n]=e.position,r=(0,E.useRef)(null),{select:i,hover:a}=F.getState(),o=F(t=>t.selected===e.id||t.hovered===e.id),s=F(t=>t.selected!==null&&t.selected!==e.id),c=e.shape===`pearl`,l=(0,E.useMemo)(()=>e.palette?e.palette.map(e=>new x(e)):c?Wt(e.type).map(e=>e.clone()):Wt(e.type),[c,e.type,e.palette]),u=(0,E.useMemo)(()=>Ht(e.id),[e.id]);return y((e,t)=>{c&&Gt(l,e.clock.elapsedTime),Kt(r.current,t,o?1:0,s?.5:1,c?l:void 0)}),(0,R.jsxs)(`group`,{ref:r,position:[t,0,n],onPointerOver:t=>{t.stopPropagation(),a(e.id),document.body.style.cursor=`pointer`},onPointerOut:()=>{a(null),document.body.style.cursor=`auto`},onClick:t=>{t.stopPropagation(),i(e.id)},children:[(0,R.jsx)(Lt,{data:e,colors:l,seed:u}),(0,R.jsx)(Vt,{building:e,active:o})]})}function Yt(){let e=(0,E.useRef)(null);return y((t,n)=>{Kt(e.current,n,0,.85)}),(0,R.jsx)(`group`,{ref:e,raycast:()=>null,children:ke.map((e,t)=>{let[n,r,i]=e.size,a=Wt(e.type);return(0,R.jsxs)(`mesh`,{position:[e.position[0],r/2,e.position[1]],raycast:()=>null,children:[(0,R.jsx)(`boxGeometry`,{args:[n,r,i]}),(0,R.jsx)(Ge,{transparent:!0,uHeight:r,uSeed:t*.137%1,uOpacity:.85,uBottom:a[0],uTop:a[1],uScan:a[2],uWindow:a[3],uFlood:e.type===`historic`?1:0})]},t)})})}function Xt(e,t=1.4,n=3){let r=e.length,a=[];for(let n=0;n<r;n++){let o=e[(n-1+r)%r],s=e[n],c=e[(n+1)%r],l=new i(o[0]-s[0],0,o[1]-s[1]),u=new i(c[0]-s[0],0,c[1]-s[1]),d=Math.min(t,l.length()*.4,u.length()*.4);a.push({enter:new i(s[0],0,s[1]).addScaledVector(l.normalize(),d),exit:new i(s[0],0,s[1]).addScaledVector(u.normalize(),d)})}let o=[];for(let e=0;e<r;e++){let t=a[e].exit,s=a[(e+1)%r].enter;o.push(a[e].enter,t);let c=t.distanceTo(s),l=Math.floor(c/n);for(let e=1;e<l;e++)o.push(new i().lerpVectors(t,s,e/l))}return new c(o,!0,`centripetal`)}function Zt(){return(0,R.jsx)(`group`,{visible:F(e=>e.vehicles),children:(0,E.useMemo)(()=>Fe.map(e=>({...e,curve:Xt(e.points)})),[]).map((e,t)=>Array.from({length:e.count},(n,r)=>(0,R.jsx)(Qt,{curve:e.curve,offset:r/e.count,speed:e.speed,color:e.color},`${t}-${r}`)))})}function Qt({curve:e,offset:t,speed:n,color:r}){let a=(0,E.useRef)(null),o=(0,E.useRef)(t),s=(0,E.useMemo)(()=>new i,[]),c=(0,E.useMemo)(()=>new i,[]);return y((t,r)=>{F.getState().vehicles&&(o.current=(o.current+r*n)%1,e.getPointAt(o.current,s),e.getTangentAt(o.current,c),a.current.position.set(s.x,.22,s.z),a.current.lookAt(s.x+c.x,.22,s.z+c.z))}),(0,R.jsxs)(`group`,{ref:a,children:[(0,R.jsxs)(`mesh`,{children:[(0,R.jsx)(`boxGeometry`,{args:[.8,.34,1.6]}),(0,R.jsx)(`meshStandardMaterial`,{color:r,emissive:r,emissiveIntensity:.5,roughness:.4})]}),(0,R.jsxs)(`mesh`,{position:[0,.28,-.1],children:[(0,R.jsx)(`boxGeometry`,{args:[.68,.24,.8]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#0a1a2e`,roughness:.2,metalness:.6})]}),(0,R.jsxs)(`mesh`,{position:[0,0,.82],children:[(0,R.jsx)(`boxGeometry`,{args:[.7,.1,.05]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ffffff`})]}),(0,R.jsxs)(`mesh`,{position:[0,0,-.82],children:[(0,R.jsx)(`boxGeometry`,{args:[.7,.1,.05]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ff2a2a`})]})]})}function $t(){return(0,R.jsx)(`group`,{visible:F(e=>e.boats),children:(0,E.useMemo)(()=>Ie.map(e=>({...e,curve:Xt(e.points,2)})),[]).map((e,t)=>Array.from({length:e.count},(n,r)=>(0,R.jsx)(en,{curve:e.curve,offset:(r+.3*t)/e.count,speed:e.speed,kind:e.kind,phase:t*1.7+r},`${t}-${r}`)))})}function en({curve:e,offset:t,speed:n,kind:r,phase:a}){let o=(0,E.useRef)(null),s=(0,E.useRef)(t),c=(0,E.useMemo)(()=>new i,[]),l=(0,E.useMemo)(()=>new i,[]),u=r===`cruise`,d=u?4.6:2.8,f=u?1.5:1.1,p=u?`#ffd166`:`#9be4ff`,m=(0,E.useMemo)(()=>new oe({color:p,toneMapped:!1}),[p]),h=(0,E.useMemo)(()=>new oe({map:B(),color:p,transparent:!0,opacity:.3,depthWrite:!1,blending:2,toneMapped:!1}),[p]);return(0,E.useEffect)(()=>()=>{m.dispose(),h.dispose()},[m,h]),y((t,r)=>{if(!F.getState().boats)return;s.current=(s.current+r*n)%1,e.getPointAt(s.current,c),e.getTangentAt(s.current,l);let i=Math.sin(t.clock.elapsedTime*1.4+a)*.04;o.current.position.set(c.x,-.2+i,c.z),o.current.lookAt(c.x+l.x,-.2+i,c.z+l.z),o.current.rotation.z=Math.sin(t.clock.elapsedTime*.9+a)*.03,u&&(m.color.setHSL((t.clock.elapsedTime*.04+a*.17)%1,.9,.62),h.color.copy(m.color))}),(0,R.jsxs)(`group`,{ref:o,children:[(0,R.jsx)(`mesh`,{"rotation-x":-Math.PI/2,"position-y":.08,material:h,children:(0,R.jsx)(`planeGeometry`,{args:[d*1.6,d*1.6]})}),(0,R.jsxs)(`mesh`,{"position-y":.22,children:[(0,R.jsx)(`boxGeometry`,{args:[f,.44,d]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#132545`,roughness:.6,metalness:.3})]}),(0,R.jsxs)(`mesh`,{position:[0,.22,d/2+.3],"rotation-x":Math.PI/2,children:[(0,R.jsx)(`coneGeometry`,{args:[f/2,.6,4]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#132545`,roughness:.6,metalness:.3})]}),(0,R.jsxs)(`mesh`,{position:[0,.66,-.2],children:[(0,R.jsx)(`boxGeometry`,{args:[f*.8,u?.5:.36,d*.62]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#223a66`,emissive:p,emissiveIntensity:.25,roughness:.4})]}),(0,R.jsx)(`mesh`,{position:[0,u?.94:.86,-.2],material:m,children:(0,R.jsx)(`boxGeometry`,{args:[f*.84,.05,d*.66]})}),[-1,1].map(e=>(0,R.jsx)(`mesh`,{position:[e*f/2,.46,0],material:m,children:(0,R.jsx)(`boxGeometry`,{args:[.06,.06,d*.96]})},e)),u&&(0,R.jsxs)(`mesh`,{position:[0,1.15,-.2],children:[(0,R.jsx)(`boxGeometry`,{args:[f*.5,.36,d*.4]}),(0,R.jsx)(`meshStandardMaterial`,{color:`#2b4a7a`,emissive:`#ff8fa3`,emissiveIntensity:.35})]}),(0,R.jsxs)(`mesh`,{position:[0,u?1.5:1.1,.6],children:[(0,R.jsx)(`sphereGeometry`,{args:[.08,8,6]}),(0,R.jsx)(`meshBasicMaterial`,{color:`#ffffff`})]})]})}var tn=`/assets/fly_line-ClF0uLp4.png`;function nn(){let e=F(e=>e.flyLine&&e.sceneReady),t=ne(tn,e=>{e.wrapS=e.wrapT=ae,e.repeat.set(.4,1)}),n=(0,E.useMemo)(()=>{let e=O.P1,t=new i(e.position[0],e.size[1]+.8,e.position[1]);return D.filter(e=>e.id!==`P1`).map(e=>{let n=new i(e.position[0],e.size[1]+.3,e.position[1]),r=new i().addVectors(n,t).multiplyScalar(.5);return r.y=Math.max(n.y,t.y)+n.distanceTo(t)*.22,new o(n,r,t)})},[]);return y((e,n)=>{t.offset.x-=n*.35}),(0,R.jsx)(`group`,{visible:e,children:n.map((e,n)=>(0,R.jsxs)(`mesh`,{raycast:()=>null,children:[(0,R.jsx)(`tubeGeometry`,{args:[e,48,.14,4,!1]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,map:t,color:w.glow,opacity:.95,depthWrite:!1,blending:2})]},n))})}var rn=40;function an(){let e=(0,E.useRef)(null),t=F(e=>e.beam),[n,r]=Ae,i=(0,E.useMemo)(()=>Array.from({length:rn},()=>({x:(Math.random()-.5)*n,z:(Math.random()-.5)*r,y:Math.random()*14,len:2+Math.random()*4,speed:1.5+Math.random()*1.5,resetHeight:16+Math.random()*10,opacity:.35+Math.random()*.3})),[n,r]);return y((t,i)=>{F.getState().beam&&e.current.children.forEach(e=>{e.position.y+=e.userData.speed*i,e.position.y>e.userData.resetHeight&&(e.position.x=(Math.random()-.5)*n,e.position.z=(Math.random()-.5)*r,e.position.y=-2-Math.random()*4,e.scale.y=2+Math.random()*4)})}),(0,R.jsx)(`group`,{ref:e,visible:t,children:i.map((e,t)=>(0,R.jsxs)(`mesh`,{position:[e.x,e.y,e.z],scale:[1,e.len,1],userData:{speed:e.speed,resetHeight:e.resetHeight},children:[(0,R.jsx)(`cylinderGeometry`,{args:[.04,.04,1,6,1,!0]}),(0,R.jsx)(qe,{transparent:!0,depthWrite:!1,side:2,blending:2,uColor:`#8fc2ff`,uOpacity:e.opacity})]},t))})}var on=`/assets/guangquan01-pOZ1glDQ.png`;function sn(){let e=(0,E.useRef)(null),t=ne(on);return y(t=>{let n=t.clock.elapsedTime;e.current.children.forEach((e,t)=>{e.scale.setScalar(1+.3*Math.sin(n*3+t*1.3)),e.rotation.z=n*.8+t})}),(0,R.jsx)(`group`,{ref:e,children:Ve.map(e=>{let n=O[e],r=Math.max(n.size[0],n.size[2])*1.4;return(0,R.jsxs)(`mesh`,{"rotation-x":-Math.PI/2,position:[n.position[0],.05,n.position[1]],raycast:()=>null,children:[(0,R.jsx)(`planeGeometry`,{args:[r,r]}),(0,R.jsx)(`meshBasicMaterial`,{transparent:!0,color:w.danger,alphaMap:t,opacity:.7,depthWrite:!1,blending:2})]},e)})})}var K=new i(0,80,142),cn=new i(0,2,4);function ln(){let e=v(e=>e.camera),t=v(e=>e.controls);return(0,E.useEffect)(()=>{if(!t)return;e.position.set(0,220,300),t.target.copy(cn);let n=C.timeline({onUpdate:()=>t.update()});return n.to(e.position,{x:K.x,y:K.y,z:K.z,duration:3,delay:.3,ease:`power3.inOut`}),n.call(()=>F.setState({sceneReady:!0}),[],2.4),()=>{n.kill()}},[e,t]),(0,E.useEffect)(()=>{if(!t)return;let n=new i;return F.subscribe(e=>e.selected,r=>{let i=cn.clone(),a=K.clone();if(r){let o=O[r];i.set(o.position[0],o.size[1]*.45,o.position[1]),n.subVectors(e.position,t.target).setY(0),n.lengthSq()<.01&&n.set(0,0,1),n.normalize();let s=Math.max(o.size[1]*1.3,26);a.copy(i).addScaledVector(n,s).setY(i.y+s*.55)}C.to(e.position,{x:a.x,y:a.y,z:a.z,duration:1.4,ease:`power2.inOut`,overwrite:!0}),C.to(t.target,{x:i.x,y:i.y,z:i.z,duration:1.4,ease:`power2.inOut`,overwrite:!0,onUpdate:()=>t.update()})})},[e,t]),null}var un=S.div`
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
`;function dn(){let e=F(e=>e.autoRotate);return(0,R.jsx)(un,{children:(0,R.jsxs)(f,{camera:{fov:45,near:.1,far:900,position:[0,220,300]},dpr:[1,1.5],gl:{antialias:!0,powerPreference:`high-performance`},onPointerMissed:()=>F.getState().select(null),children:[(0,R.jsx)(`color`,{attach:`background`,args:[w.bg]}),(0,R.jsx)(`fog`,{attach:`fog`,args:[w.bg,220,520]}),(0,R.jsx)(We,{}),(0,R.jsx)(Qe,{}),(0,R.jsxs)(E.Suspense,{fallback:null,children:[(0,R.jsx)(et,{}),(0,R.jsx)(tt,{}),(0,R.jsx)(nt,{}),(0,R.jsx)(rt,{}),(0,R.jsx)(ot,{}),(0,R.jsx)(ct,{}),(0,R.jsx)(_t,{}),(0,R.jsx)(qt,{}),(0,R.jsx)(Zt,{}),(0,R.jsx)($t,{}),(0,R.jsx)(nn,{}),(0,R.jsx)(an,{}),(0,R.jsx)(sn,{}),(0,R.jsx)(re,{all:!0})]}),(0,R.jsx)(ln,{}),(0,R.jsx)(te,{makeDefault:!0,enableDamping:!0,dampingFactor:.08,zoomSpeed:.5,minDistance:20,maxDistance:280,maxPolarAngle:Math.PI/2-.06,autoRotate:e,autoRotateSpeed:.4})]})})}var q=function(e,t=1,n=0,r=``){let i=(0,E.useRef)(null),a=(0,E.useRef)(null);return(0,E.useLayoutEffect)(()=>{if(i.current){let o={toTop:`translate(0px, 100%)`,toBottom:`translate(0px, -100%)`,toLeft:`translate(100%, 0px)`,toRight:`translate(-100%, 0px)`}[e];a.current=C.fromTo(i.current,{opacity:0,transform:`${o} ${r}`},{opacity:1,transform:`translate(0px, 0px) ${r}`,duration:t,delay:n})}return a.current?.pause(),()=>{a.current?.kill()}},[n,e,t,i,r]),{ref:i,restart:(e=!0)=>{a.current?.restart(e)},reverse:()=>{a.current?.reverse()}}},fn=null,J=``,pn=``,mn=``,hn=null,gn=null,Y=1,X=!1,Z={isAutofitRunning:!1,init(e={},t=!0){t&&console.log(`autofit.js is running`);let{dw:n=1920,dh:r=1080,el:i=typeof e==`string`?e:`body`,resize:a=!0,ignore:o=[],transition:s=`none`,delay:c=0,limit:l=.1,cssMode:u=`scale`,allowScroll:d=!1}=e;fn=i;let f=document.querySelector(i);if(!f){console.error(`autofit: '${i}' is not exist`);return}let p=document.createElement(`style`),m=document.createElement(`style`);p.lang=`text/css`,m.lang=`text/css`,p.id=`autofit-style`,m.id=`ignoreStyle`,!d&&(p.innerHTML=`body {overflow: hidden;}`);let h=document.querySelector(`body`);h.appendChild(p),h.appendChild(m),f.style.height=`${r}px`,f.style.width=`${n}px`,f.style.transformOrigin=`0 0`,!d&&(f.style.overflow=`hidden`),yn(n,r,f,o,l,u),hn=()=>{clearTimeout(gn),c==0?(yn(n,r,f,o,l,u),X&&_n(J,mn,pn)):gn=setTimeout(()=>{yn(n,r,f,o,l,u),X&&_n(J,mn,pn)},c)},a&&window.addEventListener(`resize`,hn),this.isAutofitRunning=!0,setTimeout(()=>{f.style.transition=`${s}s`})},off(e=`body`){try{window.removeEventListener(`resize`,hn);let t=document.querySelector(`#autofit-style`);t&&t.remove();let n=document.querySelector(`#ignoreStyle`);n&&n.remove();let r=document.querySelector(fn||e);r&&(r.style.cssText=``),X&&vn()}catch(e){console.error(`autofit: Failed to remove normally`,e)}this.isAutofitRunning=!1,console.log(`autofit.js is off`)},elRectification:null,scale:Y};function _n(e,t=!0,n=1){if(!Z.isAutofitRunning){console.error(`autofit.js：(elRectification): autofit has not been initialized yet`);return}vn(),!e&&console.error(`autofit.js：elRectification bad selector: ${e}`),J=e,pn=n,mn=t;let r=Array.from(document.querySelectorAll(e));if(r.length==0){console.error(`autofit.js：elRectification found no element by selector: "${e}"`);return}for(let e of r){let r=Y==1?1:Number(Y)*Number(n);X||(e.originalWidth=e.clientWidth,e.originalHeight=e.clientHeight),t?(e.style.width=`${e.originalWidth*r}px`,e.style.height=`${e.originalHeight*r}px`):(e.style.width=`${100*r}%`,e.style.height=`${100*r}%`),e.style.transform=`translateZ(0) scale(${1/Number(Y)})`,e.style.transformOrigin=`0 0`}X=!0}function vn(){if(J){X=!1;for(let e of Array.from(document.querySelectorAll(J)))e.style.width=``,e.style.height=``,e.style.transform=``}}function yn(e,t,n,r,i,a=`scale`){let o=document.documentElement.clientHeight,s=document.documentElement.clientWidth;Y=s/o<e/t?s/e:o/t,Y=Math.abs(1-Y)>i?Y:1,Z.scale=+Y;let c=Math.round(o/Number(Y)),l=Math.round(s/Number(Y));n.style.height=`${c}px`,n.style.width=`${l}px`,a===`zoom`?n.style.zoom=`${Y}`:n.style.transform=`translateZ(0) scale(${Y})`;let u=document.querySelector(`#ignoreStyle`);u.innerHTML=``;for(let e of r){let t=e,n=t.el||t.dom;if(typeof t==`string`&&(n=t),!n||typeof n==`object`&&!Object.keys(n).length){console.error(`autofit: found invalid or empty selector/object: ${n}`);continue}let r=t.scale?t.scale:1/Number(Y),i=r!=Y&&t.fontSize,a=r!=Y&&t.width,o=r!=Y&&t.height;u.innerHTML+=`\n${n} { 
      transform: scale(${r})!important;
      transform-origin: 0 0;
      ${a?`width: ${a}!important;`:``}
      ${o?`height: ${o}!important;`:``}
    }`,i&&(u.innerHTML+=`\n${n} div ,${n} span,${n} a,${n} * {
        font-size: ${i}px;
      }`)}}Z.elRectification=_n;var bn=S.div`
  position: relative;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 100;
  display: flex;
  flex-direction: column;
`;function xn(e){let{designWidth:t=1920,designHeight:n=1080,...r}=e,i=(0,E.useRef)(`autofit_${Math.random().toString(36).slice(2)}`).current;return(0,E.useLayoutEffect)(()=>(Z.init({el:`#${i}`,dw:t,dh:n}),()=>{Z.off()}),[i,t,n]),(0,R.jsx)(bn,{id:i,...r})}var Sn=S.div`
  position: relative;
  flex: none;
  width: 100%;
  height: 88px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 5;
  pointer-events: auto;

  > svg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
  }
`,Cn=S.h1`
  margin: 0;
  font-size: 34px;
  font-weight: 700;
  letter-spacing: 8px;
  background: linear-gradient(to bottom, #ffffff 30%, ${w.accent});
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  filter: drop-shadow(0 4px 12px rgba(63, 182, 255, 0.45));
`,wn=S.div`
  margin-top: 2px;
  font-size: 11px;
  letter-spacing: 6px;
  color: rgba(143, 211, 255, 0.6);
`,Tn=S.div`
  position: absolute;
  top: 18px;
  ${e=>e.$right?`right: 36px;`:`left: 36px;`}
  display: flex;
  align-items: center;
  gap: 18px;
  font-size: 14px;
  color: ${w.textMuted};
  letter-spacing: 1px;
`,En=S.div`
  display: flex;
  flex-direction: column;
  gap: 2px;

  b {
    font-size: 22px;
    font-weight: 600;
    color: ${w.text};
    font-variant-numeric: tabular-nums;
    letter-spacing: 2px;
  }
`,Dn=S.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 14px;
  border: 1px solid ${w.line};
  border-radius: 999px;
  background: rgba(6, 20, 44, 0.5);

  b {
    color: ${w.glow};
    font-weight: 600;
  }
`,On=S.a`
  display: flex;
  width: 30px;
  height: 30px;
  color: ${w.text};
  opacity: 0.75;
  transition: opacity 0.2s;

  &:hover {
    opacity: 1;
  }

  svg {
    width: 100%;
    height: 100%;
  }
`,kn=[`日`,`一`,`二`,`三`,`四`,`五`,`六`];function An(){let e=new Date,t=e=>`${e}`.padStart(2,`0`);return{date:`${e.getFullYear()}-${t(e.getMonth()+1)}-${t(e.getDate())} 星期${kn[e.getDay()]}`,time:`${t(e.getHours())}:${t(e.getMinutes())}:${t(e.getSeconds())}`}}var jn=()=>(0,R.jsxs)(`svg`,{viewBox:`0 0 1920 88`,preserveAspectRatio:`none`,children:[(0,R.jsxs)(`defs`,{children:[(0,R.jsxs)(`linearGradient`,{id:`hdr-fill`,x1:`0`,y1:`0`,x2:`0`,y2:`1`,children:[(0,R.jsx)(`stop`,{offset:`0`,stopColor:`#06172f`,stopOpacity:`0.95`}),(0,R.jsx)(`stop`,{offset:`1`,stopColor:`#06172f`,stopOpacity:`0`})]}),(0,R.jsxs)(`linearGradient`,{id:`hdr-line`,x1:`0`,y1:`0`,x2:`1`,y2:`0`,children:[(0,R.jsx)(`stop`,{offset:`0`,stopColor:w.primary,stopOpacity:`0`}),(0,R.jsx)(`stop`,{offset:`0.5`,stopColor:w.primary,stopOpacity:`1`}),(0,R.jsx)(`stop`,{offset:`1`,stopColor:w.primary,stopOpacity:`0`})]}),(0,R.jsxs)(`radialGradient`,{id:`hdr-spot`,children:[(0,R.jsx)(`stop`,{offset:`0`,stopColor:`#fff`,stopOpacity:`1`}),(0,R.jsx)(`stop`,{offset:`1`,stopColor:`#fff`,stopOpacity:`0`})]}),(0,R.jsx)(`mask`,{id:`hdr-m1`,children:(0,R.jsx)(`circle`,{r:`120`,fill:`url(#hdr-spot)`,children:(0,R.jsx)(`animateMotion`,{dur:`4s`,path:`M0,64 L640,64 L700,84 L960,84`,repeatCount:`indefinite`})})}),(0,R.jsx)(`mask`,{id:`hdr-m2`,children:(0,R.jsx)(`circle`,{r:`120`,fill:`url(#hdr-spot)`,children:(0,R.jsx)(`animateMotion`,{dur:`4s`,path:`M1920,64 L1280,64 L1220,84 L960,84`,repeatCount:`indefinite`})})})]}),(0,R.jsx)(`path`,{d:`M0,0 L1920,0 L1920,64 L1280,64 L1220,84 L700,84 L640,64 L0,64 Z`,fill:`url(#hdr-fill)`}),(0,R.jsx)(`path`,{d:`M0,64 L640,64 L700,84 L1220,84 L1280,64 L1920,64`,fill:`none`,stroke:`url(#hdr-line)`,strokeWidth:`1.5`}),(0,R.jsx)(`path`,{d:`M0,64 L640,64 L700,84 L960,84`,fill:`none`,stroke:w.glow,strokeWidth:`3`,mask:`url(#hdr-m1)`}),(0,R.jsx)(`path`,{d:`M1920,64 L1280,64 L1220,84 L960,84`,fill:`none`,stroke:w.glow,strokeWidth:`3`,mask:`url(#hdr-m2)`})]});function Mn(e){let[t,n]=(0,E.useState)(An);return L(()=>n(An()),1e3),(0,R.jsxs)(Sn,{...e,children:[(0,R.jsx)(jn,{}),(0,R.jsx)(Tn,{children:(0,R.jsxs)(En,{children:[(0,R.jsx)(`b`,{children:t.time}),(0,R.jsx)(`span`,{children:t.date})]})}),(0,R.jsx)(Cn,{children:`上海外滩数字孪生运营中心`}),(0,R.jsx)(wn,{children:`THE BUND · DIGITAL TWIN OPERATION CENTER`}),(0,R.jsxs)(Tn,{$right:!0,children:[(0,R.jsxs)(Dn,{children:[(0,R.jsx)(`span`,{children:N.weather}),(0,R.jsxs)(`b`,{children:[N.temperature,`℃`]}),(0,R.jsxs)(`span`,{children:[`AQI `,N.aqi,` · `,N.aqiLevel]})]}),(0,R.jsx)(On,{href:`https://github.com/knight-L/sc-datav`,target:`_blank`,rel:`noreferrer`,title:`基于 sc-datav 模板`,children:(0,R.jsx)(`svg`,{viewBox:`0 0 16 16`,fill:`currentColor`,children:(0,R.jsx)(`path`,{d:`M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z`})})})]})]})}var Nn=S.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px;
  border-radius: 999px;
  border: 1px solid ${w.line};
  background: rgba(6, 20, 44, 0.55);
  backdrop-filter: blur(6px);
  pointer-events: auto;
`,Pn=S.button`
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border-radius: 999px;
  border: 1px solid transparent;
  font-size: 13px;
  letter-spacing: 1px;
  cursor: pointer;
  color: ${e=>e.$on?w.text:w.textMuted};
  background: ${e=>e.$on?`rgba(63, 182, 255, 0.22)`:`transparent`};
  border-color: ${e=>e.$on?w.line:`transparent`};
  transition: all 0.2s;

  &::before {
    content: "";
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: ${e=>e.$on?w.glow:`rgba(255,255,255,0.25)`};
    box-shadow: ${e=>e.$on?`0 0 8px ${w.glow}`:`none`};
  }

  &:hover {
    color: ${w.text};
    background: rgba(63, 182, 255, 0.3);
  }
`,Fn=[{key:`flyLine`,label:`数据飞线`},{key:`beam`,label:`光束特效`},{key:`labels`,label:`建筑标签`},{key:`vehicles`,label:`道路车流`},{key:`boats`,label:`江上游船`},{key:`autoRotate`,label:`自动巡览`}];function In(e){let t=F();return(0,R.jsxs)(Nn,{...e,children:[Fn.map(e=>(0,R.jsx)(Pn,{$on:t[e.key],onClick:()=>t.toggle(e.key),children:e.label},e.key)),(0,R.jsx)(Pn,{$on:t.selected!==null,onClick:()=>t.select(null),title:`取消选中，回到全景`,children:t.selected?`返回全景`:`全景视角`})]})}var Ln=S.div`
  position: relative;
  min-height: 0;
  pointer-events: auto;

  > svg {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }
`,Rn=S.div`
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  background: ${w.cardBg};
  backdrop-filter: blur(6px);
  clip-path: polygon(
    0 4%,
    3.5% 0,
    73% 0,
    79% 5%,
    100% 5%,
    100% 100%,
    0 100%
  );
`,zn=S.div`
  position: relative;
  flex: none;
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin: 0 18px;
  height: 44px;
  line-height: 44px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 1px;
  color: ${w.text};
  border-bottom: 1px solid ${w.line};

  &::before {
    content: "";
    position: absolute;
    left: 0;
    bottom: -1px;
    width: 44px;
    height: 3px;
    background: linear-gradient(90deg, ${w.glow}, transparent);
  }

  &::after {
    content: "";
    position: absolute;
    right: 0;
    bottom: -2px;
    width: 4px;
    height: 4px;
    border-radius: 2px;
    background: ${w.glow};
    box-shadow: 0 0 6px ${w.glow};
  }
`,Bn=S.span`
  font-size: 10px;
  font-weight: 400;
  letter-spacing: 2px;
  color: ${w.textDim};
  text-transform: uppercase;
`,Vn=S.span`
  margin-left: auto;
  font-size: 12px;
  font-weight: 400;
  color: ${w.textMuted};
`,Hn=S.div`
  flex: 1;
  min-height: 0;
  padding: 12px 18px 14px;
`,Un=()=>(0,R.jsxs)(`svg`,{fill:`none`,viewBox:`0 0 260 180`,preserveAspectRatio:`none`,children:[(0,R.jsx)(`path`,{fill:w.primary,fillOpacity:.9,fillRule:`evenodd`,d:`M206 10 190 0H9L0 9v171h45l4.5-4h161l4.5 4h45V10h-54Zm53 1h-53.287l-16-10H9.414L1 9.414V179h43.62l4.5-4h161.76l4.5 4H259V11Z`}),(0,R.jsx)(`path`,{fill:w.glow,d:`m51 178-2 2h162l-2-2H51ZM0 0v7l7-7H0Z`}),(0,R.jsx)(`path`,{stroke:w.glow,strokeWidth:2,d:`M1 169v10h10M259 21V11h-10`})]});function Q(e){let{title:t,subtitle:n,extra:r,children:i,...a}=e;return(0,R.jsxs)(Ln,{...a,children:[(0,R.jsxs)(Rn,{children:[(0,R.jsxs)(zn,{children:[(0,R.jsx)(`span`,{children:t}),n&&(0,R.jsx)(Bn,{children:n}),r&&(0,R.jsx)(Vn,{children:r})]}),(0,R.jsx)(Hn,{children:i})]}),(0,R.jsx)(Un,{})]})}function Wn(e){let{value:t,duration:n=2,delay:r,options:i,className:a,style:o}=e,s=(0,E.useRef)(0),c=(0,E.useRef)(null);return(0,E.useEffect)(()=>{let e,a=new IntersectionObserver(([a])=>{a.isIntersecting&&(e=C.to(s,{current:t,duration:n,delay:r,ease:`power1.out`,onUpdate(){c.current.innerHTML=s.current.toLocaleString(`zh-CN`,i)}}))},{threshold:.1});return a.observe(c.current),()=>{e?.kill(),a.disconnect()}},[t,n,r,i]),(0,R.jsx)(`div`,{ref:c,className:a,style:o,children:`0`})}var Gn=S.div`
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-rows: 1fr 1fr auto;
  grid-template-columns: 1fr 1fr;
  gap: 10px 14px;
`,Kn=S.div`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  padding: 8px 12px 8px 14px;
  border-radius: 4px;
  background: linear-gradient(
    90deg,
    rgba(63, 182, 255, 0.12),
    rgba(63, 182, 255, 0.02)
  );
  border-left: 2px solid ${e=>e.$color};

  &::after {
    content: "";
    position: absolute;
    right: 8px;
    top: 8px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: ${e=>e.$color};
    box-shadow: 0 0 8px ${e=>e.$color};
  }
`,qn=S.div`
  font-size: 12px;
  color: ${w.textMuted};
  letter-spacing: 1px;
`,Jn=S.div`
  display: flex;
  align-items: baseline;
  gap: 4px;
  color: ${e=>e.$color};
  text-shadow: 0 0 12px ${e=>e.$color}66;

  > div {
    font-size: 26px;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
    line-height: 1;
  }

  span {
    font-size: 11px;
    color: ${w.textMuted};
    text-shadow: none;
  }
`,Yn=S.div`
  grid-column: 1 / -1;
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 12px;
  color: ${w.textMuted};
`,Xn=S.div`
  display: grid;
  grid-template-columns: 64px 1fr 76px;
  align-items: center;
  gap: 10px;

  i {
    display: block;
    height: 6px;
    border-radius: 3px;
    background: rgba(255, 255, 255, 0.08);
    overflow: hidden;
  }

  i::after {
    content: "";
    display: block;
    height: 100%;
    width: var(--w);
    border-radius: 3px;
    background: linear-gradient(90deg, ${w.primary}, ${w.glow});
    box-shadow: 0 0 8px ${w.primary};
    transition: width 1.2s ease-out;
  }

  b {
    text-align: right;
    color: ${w.text};
    font-weight: 500;
    font-variant-numeric: tabular-nums;
  }
`;function Zn(){let e=I(),t=[{label:`今日客流`,value:e.visitorsToday,unit:`人次`,color:w.series[0]},{label:`实时在场`,value:e.peopleNow,unit:`人`,color:w.series[1]},{label:`今日用电`,value:e.energyToday,unit:`kWh`,color:w.series[3]},{label:`在线设备`,value:e.devicesOnline,unit:`台`,color:w.series[2]}],n=[{label:`景区承载率`,value:A.capacity,text:`${Math.round(A.capacity*100)}%`},{label:`停车位`,value:A.parkingUsed/A.parkingTotal,text:`${A.parkingUsed}/${A.parkingTotal}`},{label:`游船上座率`,value:A.boatOccupancy,text:`${Math.round(A.boatOccupancy*100)}%`}];return(0,R.jsxs)(Gn,{children:[t.map(e=>(0,R.jsxs)(Kn,{$color:e.color,children:[(0,R.jsx)(qn,{children:e.label}),(0,R.jsxs)(Jn,{$color:e.color,children:[(0,R.jsx)(Wn,{value:e.value,duration:1.6,options:{maximumFractionDigits:0}}),(0,R.jsx)(`span`,{children:e.unit})]})]},e.label)),(0,R.jsx)(Yn,{children:n.map(e=>(0,R.jsxs)(Xn,{children:[(0,R.jsx)(`span`,{children:e.label}),(0,R.jsx)(`i`,{style:{"--w":`${e.value*100}%`}}),(0,R.jsx)(`b`,{children:e.text})]},e.label))})]})}var Qn=e=>{let[t,n]=(0,E.useState)({width:0,height:0});return(0,E.useLayoutEffect)(()=>{if(!e.current)return;let t=new ResizeObserver(([e])=>{n({width:e.contentRect.width,height:e.contentRect.height})});return t.observe(e.current),()=>t.disconnect()},[e]),t};function $n(e,t,n){let r=(0,E.useRef)(null);(0,E.useEffect)(()=>{let t=setTimeout(()=>{r.current=e()},n);return()=>{clearTimeout(t),r.current&&r.current()}},[...t,n])}ge(de);var er=S.div`
  width: 100%;
  height: 100%;
`;function $(e){let t=(0,E.useRef)(null),n=(0,E.useRef)(null),r=Qn(t);ge(e.use);let i=(0,E.useMemo)(()=>e.option,[e.option]);return(0,E.useImperativeHandle)(e.ref,()=>n.current),(0,E.useLayoutEffect)(()=>(n.current=pe(t.current),()=>{n.current?.dispose(),n.current=null,t.current=null}),[]),$n(()=>{r?.width!==0&&r?.height!==0&&n.current?.resize()},[r],300),(0,E.useEffect)(()=>{n.current&&n.current.setOption(i,{notMerge:!1,lazyUpdate:!0,replaceMerge:[`series`]})},[i]),(0,R.jsx)(er,{ref:t,style:e.style})}var tr=10,nr=[w.series[0],w.series[1]],rr=(e,t,n,r=!1)=>({name:e,type:`line`,symbol:`none`,smooth:!0,lineStyle:{width:2,color:n},itemStyle:{color:n},areaStyle:{color:{type:`linear`,x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:`${n}99`},{offset:1,color:`${n}05`}]}},markPoint:r?{symbol:`rect`,symbolSize:[64,20],symbolOffset:[0,-12],itemStyle:{color:`${n}cc`},label:{color:`#fff`,fontSize:11,formatter:`峰值 {c}`},data:[{type:`max`,name:`峰值`}]}:void 0,data:t});function ir(){let e=(0,E.useRef)(null),t=(0,E.useRef)(0);return L(()=>{e.current?.dispatchAction({type:`dataZoom`,startValue:t.current,endValue:t.current+tr}),t.current=(t.current+1)%(j.hours.length-tr)},2500),(0,R.jsx)($,{ref:e,use:[ue,T,he,me,ye,_e],option:{tooltip:{trigger:`axis`,backgroundColor:`rgba(4, 16, 36, 0.9)`,borderColor:w.line,textStyle:{color:w.text,fontSize:12},valueFormatter:e=>`${Number(e).toLocaleString()} 人`},legend:{right:0,top:0,itemWidth:12,itemHeight:4,textStyle:{color:w.textMuted,fontSize:12}},grid:{top:30,bottom:4,left:4,right:8,containLabel:!0},xAxis:{type:`category`,boundaryGap:!1,data:j.hours,axisLine:{lineStyle:{color:`rgba(255,255,255,0.12)`}},axisTick:{show:!1},axisLabel:{color:w.textMuted,fontSize:11}},yAxis:{type:`value`,name:`人/时`,nameTextStyle:{color:w.textDim,align:`right`},splitLine:{lineStyle:{color:`rgba(255,255,255,0.06)`}},axisLabel:{color:w.textMuted,fontSize:11,formatter:e=>e>=1e3?`${e/1e3}k`:`${e}`}},dataZoom:{type:`slider`,show:!1,realtime:!0,startValue:0,endValue:tr},series:[rr(`今日`,j.today,nr[0],!0),rr(`昨日`,j.yesterday,nr[1])]}})}var ar=e=>({borderRadius:[3,3,0,0],color:{type:`linear`,x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:e},{offset:1,color:`${e}22`}]}});function or(){let e=(0,E.useRef)(null),t=(0,E.useRef)(0);return L(()=>{e.current?.dispatchAction({type:`showTip`,seriesIndex:0,dataIndex:t.current}),t.current=(t.current+1)%M.slots.length},3e3,!0),(0,R.jsx)($,{ref:e,use:[be,T,he,me],option:{tooltip:{trigger:`axis`,backgroundColor:`rgba(4, 16, 36, 0.9)`,borderColor:w.line,textStyle:{color:w.text,fontSize:12},axisPointer:{type:`shadow`,shadowStyle:{color:`rgba(63, 182, 255, 0.08)`}},valueFormatter:e=>`${e} 辆`},legend:{right:0,top:0,itemWidth:10,itemHeight:10,textStyle:{color:w.textMuted,fontSize:12}},grid:{top:30,bottom:4,left:4,right:8,containLabel:!0},xAxis:{type:`category`,data:M.slots.map(e=>`${e}:00`),axisLine:{lineStyle:{color:`rgba(255,255,255,0.12)`}},axisTick:{show:!1},axisLabel:{color:w.textMuted,fontSize:11,interval:1}},yAxis:{type:`value`,splitLine:{lineStyle:{color:`rgba(255,255,255,0.06)`}},axisLabel:{color:w.textMuted,fontSize:11}},series:[{name:`进场`,type:`bar`,barWidth:8,itemStyle:ar(w.series[0]),data:M.in},{name:`出场`,type:`bar`,barWidth:8,itemStyle:ar(w.series[3]),data:M.out}]}})}var sr=S.div`
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-columns: 1.15fr 1fr;
  gap: 8px;
`,cr=S.div`
  display: grid;
  grid-template-rows: repeat(6, 1fr);
  gap: 4px;
  font-size: 12px;
  color: ${w.textMuted};
`,lr=S.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  border-radius: 3px;
  background: rgba(63, 182, 255, 0.06);

  b {
    font-size: 15px;
    font-weight: 600;
    color: ${w.glow};
    font-variant-numeric: tabular-nums;
  }

  i {
    font-style: normal;
    font-size: 10px;
    color: ${w.textDim};
    margin-left: 3px;
  }
`,ur=[{label:`温度`,value:N.temperature,unit:`℃`},{label:`湿度`,value:N.humidity,unit:`%`},{label:`PM2.5`,value:N.pm25,unit:`μg/m³`},{label:`噪音`,value:N.noise,unit:`dB`},{label:`江面水位`,value:N.waterLevel,unit:`m`},{label:`风速`,value:N.wind,unit:`m/s`}];function dr(){return(0,R.jsxs)(sr,{children:[(0,R.jsx)($,{use:[ve,le,T],option:{tooltip:{backgroundColor:`rgba(4, 16, 36, 0.9)`,borderColor:w.line,textStyle:{color:w.text,fontSize:12}},radar:{center:[`50%`,`52%`],radius:`68%`,indicator:Le.map(e=>({name:e.name,max:e.max})),axisName:{color:w.textMuted,fontSize:10},axisNameGap:6,splitNumber:4,splitLine:{lineStyle:{color:`rgba(63,182,255,0.18)`}},splitArea:{areaStyle:{color:[`rgba(63,182,255,0.02)`,`rgba(63,182,255,0.06)`]}},axisLine:{lineStyle:{color:`rgba(63,182,255,0.18)`}}},series:[{type:`radar`,name:`外滩环境舒适度`,symbolSize:4,data:[{value:Le.map(e=>e.value),name:`舒适度`,lineStyle:{color:w.success,width:2},itemStyle:{color:w.success},areaStyle:{color:`${w.success}55`}}]}]}}),(0,R.jsx)(cr,{children:ur.map(e=>(0,R.jsxs)(lr,{children:[(0,R.jsx)(`span`,{children:e.label}),(0,R.jsxs)(`span`,{children:[(0,R.jsx)(`b`,{children:e.value}),(0,R.jsx)(`i`,{children:e.unit})]})]},e.label))})]})}function fr(){return(0,R.jsx)($,{use:[fe,T,me,ce],option:{color:[...w.series],tooltip:{backgroundColor:`rgba(4, 16, 36, 0.9)`,borderColor:w.line,textStyle:{color:w.text,fontSize:12},formatter:`{b}<br/>{c} 家 · {d}%`},legend:{orient:`vertical`,right:0,top:`middle`,itemWidth:8,itemHeight:8,itemGap:12,icon:`circle`,textStyle:{color:w.textMuted,fontSize:12},formatter:e=>`${e}  ${Re.find(t=>t.name===e)?.value??0} 家`},graphic:{elements:[{type:`text`,left:`22%`,top:`40%`,style:{text:`${A.merchants}`,fill:w.text,fontSize:26,fontWeight:700,align:`center`}},{type:`text`,left:`22%`,top:`58%`,style:{text:`入驻商户`,fill:w.textMuted,fontSize:11,align:`center`}}]},series:[{type:`pie`,center:[`29%`,`50%`],radius:[`58%`,`80%`],roseType:`area`,padAngle:3,itemStyle:{borderRadius:4},label:{show:!1},emphasis:{scale:!0,scaleSize:6,label:{show:!1}},data:Re}]}})}var pr=(e,t)=>{let n=(0,E.useRef)(e),r=(0,E.useRef)(0);(0,E.useEffect)(()=>{n.current=e},[e]),(0,E.useEffect)(()=>{function e(i){n.current(i),t&&(r.current=requestAnimationFrame(e))}if(t)return r.current=requestAnimationFrame(e),()=>cancelAnimationFrame(r.current)},[t])},mr=S.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  transform: translate3d(0px, 0px, 0px);
  mask-image: linear-gradient(to bottom, black 80%, transparent 100%);
  -webkit-mask-image: linear-gradient(to bottom, black 80%, transparent 100%);
`,hr=S.div`
  flex: 1 1 0;
  position: relative;
  height: 100%;
  overflow: hidden;
`,gr=S.div`
  color: #ffffff;
`,_r=S.div`
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding-inline: 0.5rem;
  font-size: 0.8rem;
  line-height: 1.25rem;
  height: 34px;
  color: rgba(255, 255, 255, 0.6);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
`,vr=S.div`
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  ${e=>({textAlign:e.$align??`left`,flex:e.$flex??1})}
`,yr=S.div`
  display: flex;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.8rem;
  line-height: 1.25rem;
  padding-inline: 0.5rem;
  margin: 2px 0;
  border-radius: 2px;
  cursor: ${e=>e.$clickable?`pointer`:`default`};
  transition: background 0.2s;

  &:nth-child(odd) {
    background: rgba(63, 182, 255, 0.06);
  }

  &:hover {
    background: rgba(63, 182, 255, 0.18);
  }

  ${e=>({height:`${e.$height}px`})}
`,br=S.div.attrs({children:`暂无数据`})`
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.5);
`;function xr(e){let{speed:t=2500,rowHeight:n=40,column:r=[],data:i=[],styles:a,onRowClick:o}=e,s=(0,E.useRef)(0),c=(0,E.useRef)(null),l=(0,E.useRef)(null),{height:u=0}=Qn(c)??{},[d,f]=(0,E.useState)(!0),[p,m]=(0,E.useState)(0),[h,g,_]=(0,E.useMemo)(()=>{let e=n+4,t=i.length*e>u&&u>0,r=Math.ceil(u/e);return[t,r,t?i.concat(i.slice(0,r)):i]},[i,n,u]),v=(0,E.useMemo)(()=>(l.current?.style.setProperty(`transform`,`translate3d(0, 0, 0)`),l.current?.style.setProperty(`transition`,`none`),_.slice(p,p+g)),[p,_,g]);return pr(e=>{e-s.current>=t&&(l.current?.style.setProperty(`transform`,`translate3d(0, ${-(n+4)}px, 0)`),l.current?.style.setProperty(`transition`,`transform 300ms ease-in 0s`),s.current=e)},d&&h),(0,R.jsxs)(mr,{onMouseEnter:()=>f(!1),onMouseLeave:()=>f(!0),children:[(0,R.jsx)(_r,{style:a?.header,children:r.map((e,t)=>(0,R.jsx)(vr,{$align:e.align,$flex:e.flex,children:e.title},t))}),(0,R.jsxs)(hr,{ref:c,children:[(0,R.jsx)(gr,{ref:l,style:a?.body,onTransitionEnd:()=>{m(e=>(e+1)%i.length)},children:v.map((e,t)=>{let a=(t+p)%i.length;return(0,R.jsx)(yr,{$height:n,$clickable:!!o,onClick:()=>o?.(e,a),children:r.map((t,n)=>(0,R.jsx)(vr,{$align:t.align,$flex:t.flex,children:t.render?t.render(e,a):e[t.dataIndex]},n))},t+p)})}),!(v.length>0)&&(0,R.jsx)(br,{})]})]})}function Sr(){let e=F(e=>e.focus);return(0,R.jsx)(xr,{rowHeight:36,data:P,onRowClick:t=>e(t.buildingId),column:[{title:`时间`,dataIndex:`time`,flex:.8},{title:`位置`,flex:1.4,render:e=>(0,R.jsx)(`span`,{style:{color:w.glow},children:O[e.buildingId]?.name??e.buildingId})},{title:`告警类型`,dataIndex:`type`,flex:1.6},{title:`等级`,align:`center`,flex:.7,render:e=>(0,R.jsx)(`span`,{style:{color:ze[e.level]},children:e.level})},{title:`状态`,align:`right`,flex:.9,render:e=>(0,R.jsxs)(`span`,{style:{color:Be[e.status]},children:[`● `,e.status]})}]})}var Cr=S.div`
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  gap: 10px;
  min-height: 0;
`,wr=S.div`
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
`,Tr=S.button`
  padding: 2px 9px;
  border-radius: 999px;
  border: 1px solid ${e=>e.$on?e.$color:`rgba(255,255,255,0.12)`};
  background: ${e=>e.$on?`${e.$color}33`:`rgba(255,255,255,0.03)`};
  color: ${e=>e.$on?w.text:w.textMuted};
  font-size: 11px;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: ${e=>e.$on?`0 0 10px ${e.$color}`:`none`};

  &:hover {
    color: ${w.text};
    border-color: ${e=>e.$color};
  }
`,Er=S.div`
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 16px;
  min-height: 0;
`,Dr=S.div`
  display: grid;
  grid-template-columns: 1.2fr 1fr 1fr;
  grid-template-rows: auto auto;
  gap: 12px 10px;
  align-content: center;
  min-height: 0;
`,Or=S.div`
  grid-column: 1 / -1;
  display: flex;
  align-items: baseline;
  gap: 10px;

  b {
    font-size: 20px;
    font-weight: 600;
    color: ${w.text};
  }

  span {
    font-size: 12px;
    color: ${w.textMuted};
  }
`,kr=S.div`
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-left: 10px;
  border-left: 1px solid ${w.line};
  font-size: 12px;
  color: ${w.textMuted};

  > div {
    display: flex;
    align-items: baseline;
    gap: 3px;
    color: ${e=>e.$color??w.glow};
    font-size: 20px;
    font-weight: 600;
    font-variant-numeric: tabular-nums;
  }

  i {
    font-style: normal;
    font-size: 11px;
    color: ${w.textMuted};
  }
`,Ar=S.div`
  display: flex;
  flex-direction: column;
  min-height: 0;

  > span {
    flex: none;
    font-size: 12px;
    color: ${w.textMuted};
  }

  > div {
    flex: 1;
    min-height: 0;
  }
`;function jr(){let e=F(e=>e.selected),t=F(e=>e.select),n=I(e=>e.peopleNow),r=I(e=>e.energyToday),i=e?O[e]:null,a=i?P.filter(e=>e.buildingId===i.id&&e.status!==`已处理`).length:P.filter(e=>e.status!==`已处理`).length,o=(0,E.useMemo)(()=>{let e=i?i.people/A.peopleNow:1;return j.today.map(t=>Math.round(t*e))},[i]),s=i?De[i.type][1]:w.primary;return(0,R.jsxs)(Cr,{children:[(0,R.jsx)(wr,{children:D.map(n=>(0,R.jsx)(Tr,{$color:De[n.type][1],$on:n.id===e,onClick:()=>t(n.id),children:n.name},n.id))}),(0,R.jsxs)(Er,{children:[(0,R.jsxs)(Dr,{children:[(0,R.jsxs)(Or,{children:[(0,R.jsx)(`b`,{children:i?i.name:`外滩全景`}),(0,R.jsx)(`span`,{children:i?`${Ee[i.type]} · ${i.height} m · ${i.floors} 层 · 建成于 ${i.builtYear} 年`:`点击 3D 建筑、建筑芯片或告警列表，查看建筑详情并定位镜头`})]}),(0,R.jsxs)(kr,{children:[(0,R.jsx)(`span`,{children:i?`当前在场`:`实时在场`}),(0,R.jsxs)(`div`,{children:[(0,R.jsx)(Wn,{value:i?i.people:n,duration:.8,options:{maximumFractionDigits:0}}),(0,R.jsx)(`i`,{children:`人`})]})]}),(0,R.jsxs)(kr,{$color:w.warn,children:[(0,R.jsx)(`span`,{children:`今日用电`}),(0,R.jsxs)(`div`,{children:[(0,R.jsx)(Wn,{value:i?i.energyToday:r,duration:.8,options:{maximumFractionDigits:0}}),(0,R.jsx)(`i`,{children:`kWh`})]})]}),(0,R.jsxs)(kr,{$color:a>0?w.danger:w.success,children:[(0,R.jsx)(`span`,{children:`未关闭告警`}),(0,R.jsxs)(`div`,{children:[(0,R.jsx)(Wn,{value:a,duration:.6,options:{maximumFractionDigits:0}}),(0,R.jsxs)(`i`,{children:[`条`,i&&` · 运行负荷 ${Math.round(i.load*100)}%`]})]})]})]}),(0,R.jsxs)(Ar,{children:[(0,R.jsxs)(`span`,{children:[i?i.name:`外滩全域`,` · 今日 24h 客流（人/时，估算）`]}),(0,R.jsx)($,{use:[be,he,T],option:{tooltip:{trigger:`axis`,backgroundColor:`rgba(4, 16, 36, 0.9)`,borderColor:w.line,textStyle:{color:w.text,fontSize:12},valueFormatter:e=>`${Number(e).toLocaleString()} 人`},grid:{top:6,bottom:2,left:2,right:2,containLabel:!0},xAxis:{type:`category`,data:j.hours,axisLine:{lineStyle:{color:`rgba(255,255,255,0.12)`}},axisTick:{show:!1},axisLabel:{color:w.textDim,fontSize:10,interval:3,formatter:e=>e.slice(0,2)}},yAxis:{type:`value`,splitLine:{lineStyle:{color:`rgba(255,255,255,0.05)`}},axisLabel:{color:w.textDim,fontSize:10,formatter:e=>e>=1e3?`${e/1e3}k`:`${e}`}},series:[{type:`bar`,name:`客流`,barWidth:`55%`,itemStyle:{borderRadius:[2,2,0,0],color:{type:`linear`,x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:s},{offset:1,color:`${s}22`}]}},data:o}]}})]})]})]})}var Mr=S.div`
  flex: 1;
  min-height: 0;
  display: grid;
  grid-template-columns: 440px 1fr 1fr 440px;
  grid-template-rows: repeat(6, minmax(0, 1fr));
  gap: 16px;
  padding: 12px 20px 20px;
`,Nr=S.div`
  grid-area: 1 / 2 / 2 / 4;
  display: flex;
  justify-content: center;
  align-items: flex-start;
`;function Pr(){let e=q(`toBottom`,.6),t=q(`toRight`,.8,.3),n=q(`toRight`,.8,.45),r=q(`toRight`,.8,.6),i=q(`toLeft`,.8,.3),a=q(`toLeft`,.8,.45),o=q(`toLeft`,.8,.6),s=q(`toTop`,.8,.7),c=q(`toBottom`,.6,.8);return(0,E.useEffect)(()=>{let l=[e,t,n,r,i,a,o,s,c];return F.subscribe(e=>e.sceneReady,e=>{e&&l.forEach(e=>e.restart())})},[]),(0,R.jsxs)(xn,{children:[(0,R.jsx)(Mn,{ref:e.ref}),(0,R.jsxs)(Mr,{children:[(0,R.jsx)(Nr,{children:(0,R.jsx)(In,{ref:c.ref})}),(0,R.jsx)(Q,{ref:t.ref,style:{gridArea:`1 / 1 / 3 / 2`},title:`外滩概况`,subtitle:`Overview`,children:(0,R.jsx)(Zn,{})}),(0,R.jsx)(Q,{ref:n.ref,style:{gridArea:`3 / 1 / 5 / 2`},title:`客流监测`,subtitle:`Visitor Flow`,extra:`单位：人/时`,children:(0,R.jsx)(ir,{})}),(0,R.jsx)(Q,{ref:r.ref,style:{gridArea:`5 / 1 / 7 / 2`},title:`车辆通行`,subtitle:`Traffic`,extra:`中山东一路 · 今日`,children:(0,R.jsx)(or,{})}),(0,R.jsx)(Q,{ref:i.ref,style:{gridArea:`1 / 4 / 3 / 5`},title:`环境监测`,subtitle:`Environment`,children:(0,R.jsx)(dr,{})}),(0,R.jsx)(Q,{ref:a.ref,style:{gridArea:`3 / 4 / 5 / 5`},title:`业态分布`,subtitle:`Business`,children:(0,R.jsx)(fr,{})}),(0,R.jsx)(Q,{ref:o.ref,style:{gridArea:`5 / 4 / 7 / 5`},title:`安防告警`,subtitle:`Alarms`,extra:`点击定位`,children:(0,R.jsx)(Sr,{})}),(0,R.jsx)(Q,{ref:s.ref,style:{gridArea:`5 / 2 / 7 / 4`},title:`建筑详情`,subtitle:`Building`,children:(0,R.jsx)(jr,{})})]})]})}var Fr=S.div`
  position: relative;
  width: 100vw;
  height: 100vh;
  overflow: clip;
`;function Ir(){return(0,E.useEffect)(()=>()=>F.getState().reset(),[]),L(()=>I.getState().tick(),3e3),(0,R.jsxs)(Fr,{children:[(0,R.jsx)(dn,{}),(0,R.jsx)(Pr,{})]})}export{Ir as default};